"""
Core module for DietAI
"""
