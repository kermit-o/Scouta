import sys
import os
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect, Response
from pydantic import BaseModel
from typing import Optional, List
import uvicorn
import asyncio
import logging

# Setup Python path
sys.path.insert(0, os.path.dirname(__file__))

# Importaciones ABSOLUTAS desde app
try:
    from app.agents.supervisor import SupervisorAgent
    from app.services.progress_service import progress_service
    from app.services.validation_service import validation_service
    from app.services.file_storage_service import file_storage_service
    from app.services.database_service import DatabaseService
except ImportError:
    # Fallback para desarrollo
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
    from agents.supervisor import SupervisorAgent
    from services.progress_service import progress_service
    from services.validation_service import validation_service
    from services.file_storage_service import file_storage_service
    from services.database_service import DatabaseService

logger = logging.getLogger(__name__)

app = FastAPI(title="Forge SaaS API", version="1.0.0")
db_service = DatabaseService()

# ... (el resto del código del main.py original)
# [Aquí irían todas las clases y endpoints del main.py completo]
EOL# Corregir imports en el main.py completo
cat > backend/app/main.py << 'EOL'
import sys
import os
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect, Response
from pydantic import BaseModel
from typing import Optional, List
import uvicorn
import asyncio
import logging

# Setup Python path
sys.path.insert(0, os.path.dirname(__file__))

# Importaciones ABSOLUTAS desde app
try:
    from app.agents.supervisor import SupervisorAgent
    from app.services.progress_service import progress_service
    from app.services.validation_service import validation_service
    from app.services.file_storage_service import file_storage_service
    from app.services.database_service import DatabaseService
except ImportError:
    # Fallback para desarrollo
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
    from agents.supervisor import SupervisorAgent
    from services.progress_service import progress_service
    from services.validation_service import validation_service
    from services.file_storage_service import file_storage_service
    from services.database_service import DatabaseService

logger = logging.getLogger(__name__)

app = FastAPI(title="Forge SaaS API", version="1.0.0")
db_service = DatabaseService()

# ... (el resto del código del main.py original)
# [Aquí irían todas las clases y endpoints del main.py completo]
