import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
﻿import sys
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from contextlib import contextmanager
import logging

# Add the app directory to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from models.project import Project, ProjectArtifact, Base
from utils.config import Config

logger = logging.getLogger(__name__)

class DatabaseService:
    def __init__(self):
        self.engine = create_engine(Config.DATABASE_URL)
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
    
    def init_db(self):
        """Initialize database tables"""
        try:
            Base.metadata.create_all(bind=self.engine)
            logger.info("Database tables created successfully")
        except Exception as e:
            logger.error(f"Error creating database tables: {e}")
            raise
    
    @contextmanager
    def get_db(self):
        """Get database session context manager"""
        session = self.SessionLocal()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            raise
        finally:
            session.close()
    
    def create_project(self, user_id: str, project_name: str, requirements: str) -> Project:
        """Create a new project in database"""
        with self.get_db() as db:
            project = Project(
                user_id=user_id,
                project_name=project_name,
                requirements=requirements
            )
            db.add(project)
            db.flush()  # Flush to get the ID without committing
            return project
    
    def update_project_result(self, project_id: str, result: str, status: str = "completed"):
        """Update project with generation result"""
        with self.get_db() as db:
            project = db.query(Project).filter(Project.id == project_id).first()
            if project:
                project.result = result
                project.status = status
                return True
        return False
    
    def get_user_projects(self, user_id: str, limit: int = 10):
        """Get projects for a specific user"""
        with self.get_db() as db:
            return db.query(Project).filter(
                Project.user_id == user_id,
                Project.is_deleted == False
            ).order_by(Project.created_at.desc()).limit(limit).all()from app.config.paths import setup_paths; setup_paths()
from app.config.paths import setup_paths; setup_paths()
