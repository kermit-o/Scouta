#!/usr/bin/env python3
import subprocess
import json
import time
import os
from datetime import datetime
import docker
import psutil

class SystemMonitor:
    def obtener_estado(self):
        return {
            "timestamp": datetime.now().isoformat(),
            "docker": self.estado_docker(),
            "archivos": self.estado_archivos(),
            "imports": self.verificar_imports(),
            "logs": self.ultimos_logs(),
            "recursos": self.estado_recursos()
        }
    
    def estado_docker(self):
        try:
            client = docker.from_env()
            containers = client.containers.list()
            return {
                "contenedores": [{
                    "nombre": c.name,
                    "estado": c.status,
                    "puertos": c.ports
                } for c in containers],
                "redes": [n.name for n in client.networks.list()],
                "imagenes": [i.tags for i in client.images.list()]
            }
        except Exception as e:
            return {"error": str(e)}
    
    def estado_archivos(self):
        estructura = {}
        for root, dirs, files in os.walk("."):
            if any(x in root for x in ['.git', '__pycache__', 'node_modules']):
                continue
            estructura[root] = {
                "directorios": dirs,
                "archivos": [f for f in files if f.endswith(('.py', '.yml', '.yaml', '.json', '.md'))]
            }
        return estructura
    
    def verificar_imports(self):
        problemas = []
        for root, _, files in os.walk("backend/app"):
            for file in files:
                if file.endswith('.py'):
                    ruta = os.path.join(root, file)
                    try:
                        with open(ruta, 'r') as f:
                            contenido = f.read()
                            if 'from ..' in contenido or 'from .' in contenido:
                                problemas.append({
                                    "archivo": ruta,
                                    "problema": "Import relativo detectado",
                                    "contenido": [line for line in contenido.split('\n') if 'from .' in line]
                                })
                    except Exception as e:
                        problemas.append({"archivo": ruta, "error": str(e)})
        return problemas
    
    def ultimos_logs(self):
        try:
            result = subprocess.run(['docker-compose', 'logs', '--tail=10'], 
                                  capture_output=True, text=True, timeout=10)
            return result.stdout.split('\n')[-10:]
        except:
            return ["No se pudieron obtener logs"]
    
    def estado_recursos(self):
        return {
            "cpu": psutil.cpu_percent(),
            "memoria": psutil.virtual_memory().percent,
            "disco": psutil.disk_usage('.').percent
        }

if __name__ == "__main__":
    monitor = SystemMonitor()
    print(json.dumps(monitor.obtener_estado(), indent=2))
