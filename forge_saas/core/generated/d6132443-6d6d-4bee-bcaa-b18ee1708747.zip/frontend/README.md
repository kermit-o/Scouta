# Flutter app

Run `flutter create .` aquí y añade login + dashboard.
