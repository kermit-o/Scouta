import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import asyncio
import json
from typing import Dict, Set
from fastapi import WebSocket
from collections import defaultdict
import logging

logger = logging.getLogger(__name__)

class ProgressService:
    def __init__(self):
        self.active_connections: Dict[str, Set[WebSocket]] = defaultdict(set)
        self.progress_data: Dict[str, Dict] = {}

    async def connect(self, websocket: WebSocket, project_id: str):
        await websocket.accept()
        self.active_connections[project_id].add(websocket)
        logger.info(f"WebSocket connected for project {project_id}")

    def disconnect(self, websocket: WebSocket, project_id: str):
        self.active_connections[project_id].discard(websocket)
        if not self.active_connections[project_id]:
            del self.active_connections[project_id]
        logger.info(f"WebSocket disconnected for project {project_id}")

    async def update_progress(self, project_id: str, progress: Dict):
        self.progress_data[project_id] = progress
        if project_id in self.active_connections:
            disconnected = set()
            for websocket in self.active_connections[project_id]:
                try:
                    await websocket.send_json(progress)
                except Exception as e:
                    logger.error(f"Error sending progress: {e}")
                    disconnected.add(websocket)
            for websocket in disconnected:
                self.disconnect(websocket, project_id)

    def get_progress(self, project_id: str) -> Dict:
        return self.progress_data.get(project_id, {
            "status": "unknown",
            "progress": 0,
            "current_step": "Not started",
            "details": {}
        })

# Global instance
progress_service = ProgressService()
from app.config.paths import setup_paths; setup_paths()
from app.config.paths import setup_paths; setup_paths()
