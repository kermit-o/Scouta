# backend/app/models/project.py
from sqlalchemy import Column, Integer, String, Text, DateTime, JSON, Boolean
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
import uuid

Base = declarative_base()

class Project(Base):
    __tablename__ = "projects"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(255), nullable=False, index=True)
    project_name = Column(String(255), nullable=False)
    requirements = Column(Text, nullable=False)
    status = Column(String(50), default="pending")  # pending, processing, completed, failed
    result = Column(Text)  # Store serialized project result
    generated_plan = Column(Text)  # Store the generated project plan
    technology_stack = Column(JSON)  # Store recommended tech stack
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_deleted = Column(Boolean, default=False)

class ProjectArtifact(Base):
    __tablename__ = "project_artifacts"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    project_id = Column(String(36), nullable=False, index=True)
    artifact_type = Column(String(50))  # code, documentation, tests, config
    file_path = Column(String(500))
    content = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)