import streamlit as st
import requests
import json
from typing import Optional
import time

# Configuración - Usar el nombre del servicio Docker en lugar de localhost
API_URL = "http://backend:8000"  # Cambiado de localhost:8000 a backend:8000

class ForgeUI:
    def __init__(self, api_url: str = API_URL):
        self.api_url = api_url
    
    def render_header(self):
        """Render the application header"""
        st.markdown('<h1 class="main-header">⚒️ Forge SaaS</h1>', unsafe_allow_html=True)
        st.markdown("""
        **Transform your ideas into complete software projects**  
        Provide high-level instructions, and our AI agents will handle the rest: planning, design, development, testing, and deployment.
        """)
    
    def render_project_input(self):
        """Render project requirements input form"""
        with st.form("project_requirements_form"):
            st.subheader("Describe Your Project")
            
            project_name = st.text_input("Project Name*", placeholder="e.g., Task Management App")
            project_type = st.selectbox(
                "Project Type*",
                ["Web Application", "Mobile App", "API Service", "Data Analysis Tool", "Other"]
            )
            
            st.subheader("Project Requirements")
            requirements = st.text_area(
                "Describe your project in detail*",
                height=200,
                placeholder="Example: 'Create a web-based task management application with user authentication, task creation with deadlines, real-time updates, and team collaboration features. Include a modern React frontend and Python backend with PostgreSQL.'"
            )
            
            # Advanced options
            with st.expander("Advanced Options"):
                tech_preferences = st.text_input(
                    "Technology Preferences (optional)",
                    placeholder="e.g., React, Python, PostgreSQL, AWS"
                )
                special_requirements = st.text_area(
                    "Special Requirements (optional)",
                    placeholder="e.g., Must support OAuth 2.0, need CI/CD pipeline, include unit tests"
                )
            
            submitted = st.form_submit_button("🚀 Generate Project", type="primary")
            
            if submitted:
                if not all([project_name, project_type, requirements]):
                    st.error("Please fill in all required fields (marked with *)")
                    return None
                
                return {
                    "project_name": project_name,
                    "project_type": project_type,
                    "requirements": requirements,
                    "tech_preferences": tech_preferences,
                    "special_requirements": special_requirements
                }
        return None
    
    def create_project(self, project_data: dict):
        """Send project creation request to backend API"""
        try:
            payload = {
                "requirements": f"""
                Project Name: {project_data['project_name']}
                Type: {project_data['project_type']}
                Requirements: {project_data['requirements']}
                Technology Preferences: {project_data['tech_preferences']}
                Special Requirements: {project_data['special_requirements']}
                """,
                "user_id": "demo_user",
                "project_name": project_data['project_name']
            }
            
            with st.spinner("🤖 AI agents are working on your project..."):
                response = requests.post(
                    f"{self.api_url}/api/projects/create",
                    json=payload,
                    timeout=300
                )
                
                if response.status_code == 200:
                    return response.json()
                else:
                    st.error(f"API Error: {response.text}")
                    return None
                    
        except requests.exceptions.RequestException as e:
            st.error(f"Connection error: {e}")
            return None
    
    def render_project_result(self, result: dict):
        """Render project generation results"""
        if result and result.get('status') == 'success':
            st.success("✅ Project generated successfully!")
            
            # Create tabs for different project aspects
            tab1, tab2, tab3, tab4 = st.tabs([
                "📋 Project Plan", "🏗️ Architecture", "💻 Generated Code", "📊 Overview"
            ])
            
            with tab1:
                st.subheader("Project Plan")
                st.markdown(result.get('result', 'No plan generated'))
            
            with tab2:
                st.subheader("System Architecture")
                st.info("Architecture diagrams will be generated in future versions")
            
            with tab3:
                st.subheader("Generated Code Structure")
                st.info("Code files and structure will be displayed here")
            
            with tab4:
                st.subheader("Project Overview")
                col1, col2 = st.columns(2)
                
                with col1:
                    st.metric("Estimated Timeline", "2-4 weeks")
                    st.metric("Complexity", "Medium")
                
                with col2:
                    st.metric("Recommended Team Size", "2 developers")
                    st.metric("Success Probability", "85%")
            
            # Action buttons
            col1, col2, col3 = st.columns(3)
            with col1:
                if st.button("📥 Download Project", type="primary"):
                    st.info("Download feature coming soon!")
            with col2:
                if st.button("🔄 Refine Project"):
                    st.info("Refinement feature coming soon!")
            with col3:
                if st.button("🚀 Deploy Project"):
                    st.info("Deployment feature coming soon!")
                    
        else:
            error_msg = result.get('error', 'Unknown error') if result else 'No response from server'
            st.error(f"❌ Project generation failed: {error_msg}")
    
    def render_project_history(self):
        """Render project history sidebar"""
        st.sidebar.title("📚 Your Projects")
        
        # Placeholder for project history
        projects = [
            {"name": "Task Manager App", "status": "completed", "date": "2024-01-15"},
            {"name": "E-commerce API", "status": "in progress", "date": "2024-01-14"},
            {"name": "Data Dashboard", "status": "completed", "date": "2024-01-12"}
        ]
        
        for project in projects:
            with st.sidebar.expander(f"{project['name']} - {project['date']}"):
                st.caption(f"Status: {project['status']}")
                if st.button("View", key=f"view_{project['name']}"):
                    st.info("Project viewing coming soon!")
    
    def run(self):
        """Main application runner"""
        self.render_header()
        self.render_project_history()
        
        project_data = self.render_project_input()
        
        if project_data:
            result = self.create_project(project_data)
            if result:
                self.render_project_result(result)

# Run the application
if __name__ == "__main__":
    ui = ForgeUI()
    ui.run()
