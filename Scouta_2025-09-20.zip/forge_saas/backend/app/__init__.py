import sys
import os

# Add the app directory to Python path
sys.path.insert(0, os.path.dirname(__file__))
