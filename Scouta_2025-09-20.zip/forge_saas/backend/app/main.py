from __future__ import annotations
from typing import Optional, Dict, Any, List
from fastapi import FastAPI, HTTPException, Query
from sqlalchemy.orm import Session
from uuid import uuid4
from datetime import datetime
import json

from app.services.database_service import DatabaseService
from app.models.project import Project

app = FastAPI(title="Forge SaaS Backend", version="0.1.0")
db_service = DatabaseService()

from fastapi.middleware.cors import CORSMiddleware

origins = [
    "http://localhost:8501",
    "https://*.app.github.dev",   # Codespaces
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _coerce_ts(x):
    return x if isinstance(x, datetime) else x

def _coerce_tech(x):
    if x is None or x == "null" or x == "":
        return None
    if isinstance(x, str):
        try:
            return json.loads(x)
        except Exception:
            return x
    return x

def serialize_project(p: Project) -> Dict[str, Any]:
    return {
        "id": str(p.id),
        "user_id": p.user_id,
        "project_name": p.project_name,
        "requirements": p.requirements,
        "status": p.status,
        "technology_stack": _coerce_tech(getattr(p, "technology_stack", None)),
        "generated_plan": getattr(p, "generated_plan", None),
        "result": getattr(p, "result", None),
        "created_at": _coerce_ts(getattr(p, "created_at", None)),
        "updated_at": _coerce_ts(getattr(p, "updated_at", None)),
        "is_deleted": bool(getattr(p, "is_deleted", False)),
    }

@app.get("/api/health")
def health() -> Dict[str, str]:
    return {"status": "ok"}

@app.post("/api/projects", status_code=201)
def create_project(payload: Dict[str, Any]):
    for f in ("user_id","project_name","requirements"):
        if not payload.get(f):
            raise HTTPException(status_code=422, detail=f"Field '{f}' is required")
    with db_service.get_db() as db:
        project = Project(
            id=str(uuid4()),
            user_id=payload["user_id"],
            project_name=payload["project_name"],
            requirements=payload["requirements"],
            status="pending",
            generated_plan=None,
            technology_stack=None,
        )
        db.add(project)
        db.flush()
        db.refresh(project)
        return serialize_project(project)

@app.get("/api/projects")
def list_projects(limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0)):
    with db_service.get_db() as db:
        q = db.query(Project).filter(Project.is_deleted == False).order_by(Project.created_at.desc())
        rows = q.offset(offset).limit(limit).all()
        return [serialize_project(x) for x in rows]

@app.get("/api/projects/{project_id}")
def get_project(project_id: str):
    with db_service.get_db() as db:
        project: Optional[Project] = db.get(Project, project_id)
        if not project or project.is_deleted:
            raise HTTPException(status_code=404, detail="Project not found")
        return serialize_project(project)

@app.post("/api/projects/{project_id}/plan")
def plan_project(project_id: str):
    with db_service.get_db() as db:
        project: Optional[Project] = db.get(Project, project_id)
        if not project or project.is_deleted:
            raise HTTPException(status_code=404, detail="Project not found")
        steps = [
            {"order": 1, "name": "Validate scaffold", "done": True},
            {"order": 2, "name": "DB schema projects/artifacts", "done": True},
            {"order": 3, "name": "MVP endpoints", "done": False},
            {"order": 4, "name": "UI wiring", "done": False},
        ]
        tech = {"backend": "FastAPI", "db": "Postgres", "ui": "Streamlit"}
        project.generated_plan = f"Steps: {len(steps)}; First: {steps[0]['name']}"
        project.technology_stack = tech
        project.status = "processing"
        db.add(project)
        db.flush()
        db.refresh(project)
        return serialize_project(project)

@app.get("/api/progress/{project_id}")
def get_progress(project_id: str) -> Dict[str, Any]:
    with db_service.get_db() as db:
        project: Optional[Project] = db.get(Project, project_id)
        if not project or project.is_deleted:
            raise HTTPException(status_code=404, detail="Project not found")
        status_map = {"pending": 10, "processing": 40, "completed": 100, "failed": 0}
        return {"project_id": str(project.id), "status": project.status, "progress": status_map.get(project.status, 0)}
    

from fastapi.responses import JSONResponse
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import ResponseValidationError, RequestValidationError
from sqlalchemy.exc import IntegrityError, ProgrammingError

@app.exception_handler(ResponseValidationError)
async def on_response_validation(request, exc: ResponseValidationError):
    return JSONResponse(status_code=500, content={
        "detail": "Response validation failed",
        "errors": jsonable_encoder(exc.errors()),
    })

@app.exception_handler(RequestValidationError)
async def on_request_validation(request, exc: RequestValidationError):
    return JSONResponse(status_code=422, content={"detail": jsonable_encoder(exc.errors())})

@app.exception_handler(IntegrityError)
async def on_integrity_error(request, exc: IntegrityError):
    return JSONResponse(status_code=422, content={"detail": "Database constraint error", "hint": str(exc.orig)})

@app.exception_handler(ProgrammingError)
async def on_programming_error(request, exc: ProgrammingError):
    return JSONResponse(status_code=400, content={"detail": "Invalid database operation", "hint": str(exc.orig)})


# Temporary debugging

# Add this after creating the app
