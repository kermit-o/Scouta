import os
import json
import requests
import inspect
import traceback, logging, requests, streamlit as st

API_URL = os.getenv("API_URL", "http://backend:8000")

st.set_page_config(page_title="Forge SaaS", layout="wide")


def container_with_optional_border(border: bool = False):
    params = inspect.signature(st.container).parameters
    if 'border' in params:
        return st.container(border=border)
    # Fallback para versiones viejas
    return st.container()


# ---- Header / Health ---------------------------------------------------------
col1, col2 = st.columns([3,1])
with col1:
    st.title("Forge SaaS")
with col2:
    try:
        r = requests.get(f"{API_URL}/api/health", timeout=3)
        ok = (r.status_code == 200 and r.json().get("status") == "ok")
    except Exception:
        ok = False
    st.metric("Backend", "OK" if ok else "DOWN")

st.caption(f"API_URL = `{API_URL}`")

# ---- Create Project ----------------------------------------------------------
st.subheader("Crear proyecto")
with st.form("create_form", clear_on_submit=True):
    user_id = st.text_input("User ID", value="outman")
    project_name = st.text_input("Project name", value="Forge MVP")
    requirements = st.text_area("Requirements", value="Endpoints + UI wiring")
    submitted = st.form_submit_button("Crear")
    if submitted:
        try:
            payload = {"user_id": user_id, "project_name": project_name, "requirements": requirements}
            r = requests.post(f"{API_URL}/api/projects", json=payload, timeout=10)
            if r.ok:
                st.success(f"Creado: {r.json().get('id')}")
            else:
                st.error(f"Error {r.status_code}: {r.text}")
        except Exception as e:
            st.error(f"Error creando proyecto: {e}")

st.markdown("---")

# ---- List & Actions ----------------------------------------------------------
st.subheader("Proyectos")
try:
    r = requests.get(f"{API_URL}/api/projects", timeout=10)
    if not r.ok:
        st.error(f"Error listando: {r.status_code} {r.text}")
    else:
        data = r.json()
        if not data:
            st.info("No hay proyectos aún.")
        else:
            for p in data:
                with container_with_optional_border(border=True):
                    c1, c2, c3, c4 = st.columns([4,2,2,2])
                    with c1:
                        st.markdown(f"**{p['project_name']}** · `{p['id']}`")
                        st.caption(f"User: {p['user_id']} · Status: **{p['status']}**")
                        st.caption(f"Reqs: {p['requirements']}")
                    with c2:
                        if st.button("Planificar", key=f"plan_{p['id']}"):
                            try:
                                rp = requests.post(f"{API_URL}/api/projects/{p['id']}/plan", timeout=20)
                                if rp.ok:
                                    st.success("Plan actualizado a 'processing'")
                                else:
                                    st.error(f"Error {rp.status_code}: {rp.text}")
                            except Exception as e:
                                st.error(f"Error planificar: {e}")
                    with c3:
                        if st.button("Ver progreso", key=f"prog_{p['id']}"):
                            try:
                                rg = requests.get(f"{API_URL}/api/progress/{p['id']}", timeout=10)
                                if rg.ok:
                                    pj = rg.json()
                                    st.write(pj)
                                    st.progress(min(1.0, (pj.get('progress') or 0)/100))
                                else:
                                    st.error(f"Error {rg.status_code}: {rg.text}")
                            except Exception as e:
                                st.error(f"Error progreso: {e}")
                    with c4:
                        tech = p.get("technology_stack")
                        if tech is None:
                            st.caption("Tech: —")
                        else:
                            st.json(tech if isinstance(tech, (dict, list)) else {"raw": str(tech)})

except Exception as e:
    st.error(f"Fallo listando proyectos: {e}")

log = logging.getLogger("ui")

st.subheader("Proyectos")

try:
    r = requests.get("http://backend:8000/api/projects", timeout=10)
    r.raise_for_status()
    projects = r.json()

    # DEBUG: mostrar el JSON crudo para detectar campos que la UI no espera
    st.write(projects)

    # ... tu render actual (containers/columns/expanders) ...
except Exception as e:
    log.exception("Error listando proyectos")
    st.error(f"Fallo listando proyectos: {e}")
    st.code("".join(traceback.format_exc()))

