export interface Job {
  id: string
  title: string
  category: string
  price: number
  distance: string
  location: {
    lat: number
    lng: number
    address: string
  }
  description: string
  postedBy: {
    name: string
    avatar: string
    rating: number
    jobsCompleted: number
  }
  postedAt: string
  estimatedDuration: string
  requirements?: string[]
  status?: "open" | "in-progress" | "completed" | "disputed"
  bids?: Bid[]
  contract?: Contract
}

export interface Professional {
  id: string
  name: string
  avatar: string
  profession: string
  rating: number
  jobsCompleted: number
  hourlyRate: number
  verified: boolean
}

export interface Message {
  id: string
  name: string
  avatar: string
  lastMessage: string
  timestamp: string
  unread: number
}

export interface User {
  id: string
  email: string
  name: string
  avatar: string
  role: "client" | "professional" | "admin"
  country: string
  phone?: string
  verified: boolean
  kycStatus: "pending" | "submitted" | "verified" | "rejected"
  rating: number
  jobsCompleted: number
  createdAt: string
}

export interface Bid {
  id: string
  jobId: string
  professional: Professional
  amount: number
  message: string
  estimatedDuration: string
  createdAt: string
  status: "pending" | "accepted" | "rejected"
}

export interface Contract {
  id: string
  jobId: string
  clientId: string
  professionalId: string
  agreedAmount: number
  escrowStatus: "pending" | "funded" | "released" | "refunded" | "disputed"
  startDate: string
  expectedEndDate: string
  actualEndDate?: string
  status: "active" | "completed" | "cancelled" | "disputed"
  milestones?: Milestone[]
}

export interface Milestone {
  id: string
  title: string
  amount: number
  status: "pending" | "in-progress" | "completed" | "approved"
  dueDate: string
}

export interface Review {
  id: string
  jobId: string
  reviewerId: string
  revieweeId: string
  rating: number
  comment: string
  photos?: string[]
  createdAt: string
  response?: string
}

export interface Dispute {
  id: string
  contractId: string
  raisedBy: string
  reason: string
  description: string
  evidence?: string[]
  status: "open" | "under-review" | "resolved" | "escalated"
  resolution?: string
  createdAt: string
  resolvedAt?: string
}

export interface KYCDocument {
  id: string
  userId: string
  type: "id" | "passport" | "driver-license" | "proof-of-address"
  status: "pending" | "verified" | "rejected"
  uploadedAt: string
  rejectionReason?: string
}

export type Country = {
  code: string
  name: string
  flag: string
  currency: string
}

export const COUNTRIES: Country[] = [
  { code: "US", name: "United States", flag: "🇺🇸", currency: "USD" },
  { code: "MX", name: "México", flag: "🇲🇽", currency: "MXN" },
  { code: "ES", name: "España", flag: "🇪🇸", currency: "EUR" },
  { code: "AR", name: "Argentina", flag: "🇦🇷", currency: "ARS" },
  { code: "CO", name: "Colombia", flag: "🇨🇴", currency: "COP" },
  { code: "CL", name: "Chile", flag: "🇨🇱", currency: "CLP" },
  { code: "PE", name: "Perú", flag: "🇵🇪", currency: "PEN" },
  { code: "BR", name: "Brasil", flag: "🇧🇷", currency: "BRL" },
]
