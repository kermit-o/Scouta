import type { Job, Professional, Message } from "./types"

export const nearbyJobs: Job[] = [
  {
    id: "1",
    title: "Furniture Assembly",
    category: "Home Services",
    price: 75,
    distance: "0.8 km",
    location: {
      lat: 33.5731,
      lng: -7.5898,
      address: "Maarif, Casablanca"
    },
    description: "Need help assembling a new IKEA wardrobe and desk. All tools and instructions will be provided. Should take approximately 2-3 hours.",
    postedBy: {
      name: "Sarah M.",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
      rating: 4.9,
      jobsCompleted: 47
    },
    postedAt: "2 hours ago",
    estimatedDuration: "2-3 hours",
    requirements: ["Experience with furniture assembly", "Own tools preferred"]
  },
  {
    id: "2",
    title: "Dog Walking",
    category: "Pet Care",
    price: 25,
    distance: "1.2 km",
    location: {
      lat: 33.5771,
      lng: -7.6158,
      address: "Anfa, Casablanca"
    },
    description: "Looking for a reliable dog walker for my golden retriever. Daily walks needed, 1 hour each session.",
    postedBy: {
      name: "Ahmed K.",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
      rating: 4.8,
      jobsCompleted: 23
    },
    postedAt: "4 hours ago",
    estimatedDuration: "1 hour",
    requirements: ["Love for animals", "Reliable schedule"]
  },
  {
    id: "3",
    title: "Garden Cleanup",
    category: "Outdoor",
    price: 120,
    distance: "2.1 km",
    location: {
      lat: 33.5631,
      lng: -7.6098,
      address: "Gauthier, Casablanca"
    },
    description: "Spring garden cleanup needed. Tasks include weeding, pruning shrubs, and general tidying. Medium-sized garden.",
    postedBy: {
      name: "Maria L.",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
      rating: 5.0,
      jobsCompleted: 89
    },
    postedAt: "Yesterday",
    estimatedDuration: "4-5 hours",
    requirements: ["Gardening experience", "Own tools"]
  },
  {
    id: "4",
    title: "Plumbing Repair",
    category: "Home Services",
    price: 95,
    distance: "0.5 km",
    location: {
      lat: 33.5851,
      lng: -7.6028,
      address: "Racine, Casablanca"
    },
    description: "Leaky faucet in bathroom needs fixing. Also have a slow draining sink that needs attention.",
    postedBy: {
      name: "Youssef B.",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
      rating: 4.7,
      jobsCompleted: 156
    },
    postedAt: "30 minutes ago",
    estimatedDuration: "1-2 hours",
    requirements: ["Licensed plumber", "Emergency availability"]
  },
  {
    id: "5",
    title: "Move Help",
    category: "Moving",
    price: 200,
    distance: "3.4 km",
    location: {
      lat: 33.5531,
      lng: -7.6398,
      address: "Ain Diab, Casablanca"
    },
    description: "Need 2 strong helpers for apartment move. 2 bedroom apartment, 3rd floor no elevator. Moving to a building with elevator.",
    postedBy: {
      name: "Karim T.",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
      rating: 4.6,
      jobsCompleted: 12
    },
    postedAt: "5 hours ago",
    estimatedDuration: "4-6 hours",
    requirements: ["Physical strength", "Team of 2 preferred"]
  }
]

export const professionals: Professional[] = [
  {
    id: "1",
    name: "Mohamed A.",
    avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100&h=100&fit=crop",
    profession: "Electrician",
    rating: 4.9,
    jobsCompleted: 234,
    hourlyRate: 45,
    verified: true
  },
  {
    id: "2",
    name: "Fatima Z.",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=100&h=100&fit=crop",
    profession: "House Cleaner",
    rating: 5.0,
    jobsCompleted: 412,
    hourlyRate: 35,
    verified: true
  },
  {
    id: "3",
    name: "Hassan M.",
    avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=100&h=100&fit=crop",
    profession: "Plumber",
    rating: 4.8,
    jobsCompleted: 189,
    hourlyRate: 50,
    verified: true
  },
  {
    id: "4",
    name: "Amina B.",
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100&h=100&fit=crop",
    profession: "Interior Painter",
    rating: 4.7,
    jobsCompleted: 67,
    hourlyRate: 40,
    verified: false
  }
]

export const messages: Message[] = [
  {
    id: "1",
    name: "Sarah M.",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
    lastMessage: "Great! See you tomorrow at 10am",
    timestamp: "2m ago",
    unread: 2
  },
  {
    id: "2",
    name: "Mohamed A.",
    avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100&h=100&fit=crop",
    lastMessage: "The job is completed, thank you!",
    timestamp: "1h ago",
    unread: 0
  },
  {
    id: "3",
    name: "Fatima Z.",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=100&h=100&fit=crop",
    lastMessage: "I can start next Monday",
    timestamp: "3h ago",
    unread: 1
  },
  {
    id: "4",
    name: "Ahmed K.",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
    lastMessage: "Thanks for the quick response!",
    timestamp: "Yesterday",
    unread: 0
  }
]
