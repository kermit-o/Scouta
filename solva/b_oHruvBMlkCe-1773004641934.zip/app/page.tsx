"use client"

import { useState } from "react"
import { BottomNav } from "@/components/bottom-nav"
import { HomeScreen } from "@/components/screens/home-screen"
import { SearchScreen } from "@/components/screens/search-screen"
import { JobsScreen } from "@/components/screens/jobs-screen"
import { MessagesScreen } from "@/components/screens/messages-screen"
import { ProfileScreen } from "@/components/screens/profile-screen"
import { JobDetailSheet } from "@/components/job-detail-sheet"
import { LoginScreen } from "@/components/screens/auth/login-screen"
import { RegisterScreen } from "@/components/screens/auth/register-screen"
import { OnboardingScreen } from "@/components/screens/auth/onboarding-screen"
import { PostJobScreen } from "@/components/screens/post-job-screen"
import { BidDetailScreen } from "@/components/screens/bid-detail-screen"
import { ContractScreen } from "@/components/screens/contract-screen"
import { ReviewScreen } from "@/components/screens/review-screen"
import { KYCScreen } from "@/components/screens/kyc-screen"
import { DisputeScreen } from "@/components/screens/dispute-screen"
import { GuaranteeScreen } from "@/components/screens/guarantee-screen"
import { AdminScreen } from "@/components/screens/admin-screen"
import type { Job, User, Contract } from "@/lib/types"

type AuthState = "login" | "register" | "onboarding" | "authenticated"
type Screen = "home" | "search" | "jobs" | "messages" | "profile" | "post-job" | "bid-detail" | "contract" | "review" | "kyc" | "dispute" | "guarantee" | "admin"

export default function SolvaApp() {
  const [authState, setAuthState] = useState<AuthState>("login")
  const [activeTab, setActiveTab] = useState<string>("home")
  const [currentScreen, setCurrentScreen] = useState<Screen>("home")
  const [selectedJob, setSelectedJob] = useState<Job | null>(null)
  const [selectedContract, setSelectedContract] = useState<Contract | null>(null)
  const [user, setUser] = useState<User | null>(null)

  const handleLogin = () => {
    setAuthState("onboarding")
  }

  const handleRegister = () => {
    setAuthState("onboarding")
  }

  const handleOnboardingComplete = (data: { country: string; role: "client" | "professional" }) => {
    setUser({
      id: "user-1",
      email: "usuario@solva.com",
      name: "Usuario Demo",
      avatar: "/placeholder.svg?height=100&width=100",
      role: data.role,
      country: data.country,
      verified: false,
      kycStatus: "pending",
      rating: 0,
      jobsCompleted: 0,
      createdAt: new Date().toISOString(),
    })
    setAuthState("authenticated")
  }

  const handleJobSelect = (job: Job) => {
    setSelectedJob(job)
  }

  const handleCloseJobDetail = () => {
    setSelectedJob(null)
  }

  const handleNavigate = (screen: Screen) => {
    setCurrentScreen(screen)
  }

  const handleTabChange = (tab: string) => {
    setActiveTab(tab)
    setCurrentScreen(tab as Screen)
  }

  // Auth screens
  if (authState === "login") {
    return (
      <div className="mx-auto max-w-md min-h-screen">
        <LoginScreen 
          onLogin={handleLogin} 
          onSwitchToRegister={() => setAuthState("register")} 
        />
      </div>
    )
  }

  if (authState === "register") {
    return (
      <div className="mx-auto max-w-md min-h-screen">
        <RegisterScreen 
          onRegister={handleRegister} 
          onSwitchToLogin={() => setAuthState("login")} 
        />
      </div>
    )
  }

  if (authState === "onboarding") {
    return (
      <div className="mx-auto max-w-md min-h-screen">
        <OnboardingScreen onComplete={handleOnboardingComplete} />
      </div>
    )
  }

  // Main app screens
  const renderScreen = () => {
    switch (currentScreen) {
      case "home":
        return <HomeScreen onJobSelect={handleJobSelect} onNavigate={handleNavigate} user={user} />
      case "search":
        return <SearchScreen />
      case "jobs":
        return <JobsScreen onJobSelect={handleJobSelect} user={user} onNavigate={handleNavigate} />
      case "messages":
        return <MessagesScreen />
      case "profile":
        return <ProfileScreen user={user} onNavigate={handleNavigate} onLogout={() => setAuthState("login")} />
      case "post-job":
        return <PostJobScreen onBack={() => setCurrentScreen("home")} onSubmit={() => setCurrentScreen("jobs")} />
      case "bid-detail":
        return <BidDetailScreen job={selectedJob} onBack={() => setCurrentScreen("jobs")} onAcceptBid={(contract) => { setSelectedContract(contract); setCurrentScreen("contract") }} />
      case "contract":
        return <ContractScreen contract={selectedContract} onBack={() => setCurrentScreen("jobs")} onComplete={() => setCurrentScreen("review")} onDispute={() => setCurrentScreen("dispute")} />
      case "review":
        return <ReviewScreen contract={selectedContract} onBack={() => setCurrentScreen("jobs")} onSubmit={() => setCurrentScreen("jobs")} />
      case "kyc":
        return <KYCScreen user={user} onBack={() => setCurrentScreen("profile")} onSubmit={() => setCurrentScreen("profile")} />
      case "dispute":
        return <DisputeScreen contract={selectedContract} onBack={() => setCurrentScreen("contract")} onSubmit={() => setCurrentScreen("jobs")} />
      case "guarantee":
        return <GuaranteeScreen onBack={() => setCurrentScreen("profile")} />
      case "admin":
        return <AdminScreen onBack={() => setCurrentScreen("profile")} />
      default:
        return <HomeScreen onJobSelect={handleJobSelect} onNavigate={handleNavigate} user={user} />
    }
  }

  const showBottomNav = ["home", "search", "jobs", "messages", "profile"].includes(currentScreen)

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-md min-h-screen flex flex-col relative">
        <main className={`flex-1 ${showBottomNav ? "pb-24" : ""} overflow-y-auto`}>
          {renderScreen()}
        </main>

        {showBottomNav && (
          <BottomNav activeTab={activeTab} onTabChange={handleTabChange} />
        )}

        <JobDetailSheet 
          job={selectedJob} 
          onClose={handleCloseJobDetail}
          user={user}
          onMakeBid={() => { setCurrentScreen("bid-detail") }}
        />
      </div>
    </div>
  )
}
