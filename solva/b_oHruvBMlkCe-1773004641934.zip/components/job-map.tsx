"use client"

import { useState } from "react"
import { MapPin, Navigation } from "lucide-react"
import type { Job } from "@/lib/types"

interface JobMapProps {
  jobs: Job[]
  onJobSelect: (job: Job) => void
}

export function JobMap({ jobs, onJobSelect }: JobMapProps) {
  const [hoveredJob, setHoveredJob] = useState<string | null>(null)

  // Map bounds for Casablanca area
  const mapBounds = {
    minLat: 33.55,
    maxLat: 33.59,
    minLng: -7.65,
    maxLng: -7.58
  }

  const getJobPosition = (job: Job) => {
    const x = ((job.location.lng - mapBounds.minLng) / (mapBounds.maxLng - mapBounds.minLng)) * 100
    const y = ((mapBounds.maxLat - job.location.lat) / (mapBounds.maxLat - mapBounds.minLat)) * 100
    return { x: Math.max(10, Math.min(90, x)), y: Math.max(10, Math.min(90, y)) }
  }

  return (
    <div className="relative h-52 bg-gradient-to-br from-secondary via-secondary to-muted rounded-2xl overflow-hidden border border-border/50 shadow-[0_2px_8px_rgba(0,0,0,0.04)]">
      {/* Map Background Pattern */}
      <div className="absolute inset-0 opacity-30">
        <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          {/* Grid lines */}
          {[...Array(10)].map((_, i) => (
            <g key={i}>
              <line
                x1={i * 10}
                y1="0"
                x2={i * 10}
                y2="100"
                stroke="currentColor"
                strokeWidth="0.2"
                className="text-muted-foreground/30"
              />
              <line
                x1="0"
                y1={i * 10}
                x2="100"
                y2={i * 10}
                stroke="currentColor"
                strokeWidth="0.2"
                className="text-muted-foreground/30"
              />
            </g>
          ))}
          {/* Curved roads */}
          <path
            d="M 10 80 Q 30 60 50 55 T 90 30"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
            className="text-border"
          />
          <path
            d="M 0 40 Q 25 50 50 45 T 100 60"
            fill="none"
            stroke="currentColor"
            strokeWidth="1"
            className="text-border"
          />
          <path
            d="M 30 100 Q 40 70 55 50 T 70 0"
            fill="none"
            stroke="currentColor"
            strokeWidth="0.8"
            className="text-border"
          />
        </svg>
      </div>

      {/* Current Location */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-10">
        <div className="relative">
          <div className="w-4 h-4 bg-primary rounded-full shadow-[0_0_0_4px_rgba(37,99,235,0.2)]" />
          <div className="absolute inset-0 w-4 h-4 bg-primary rounded-full animate-ping opacity-40" />
        </div>
      </div>

      {/* Job Markers */}
      {jobs.map((job) => {
        const position = getJobPosition(job)
        const isHovered = hoveredJob === job.id
        return (
          <button
            key={job.id}
            onClick={() => onJobSelect(job)}
            onMouseEnter={() => setHoveredJob(job.id)}
            onMouseLeave={() => setHoveredJob(null)}
            className="absolute z-20 transition-all duration-300"
            style={{
              left: `${position.x}%`,
              top: `${position.y}%`,
              transform: `translate(-50%, -50%) scale(${isHovered ? 1.2 : 1})`
            }}
          >
            <div className={`
              relative flex items-center justify-center
              w-8 h-8 rounded-xl
              ${isHovered ? 'bg-primary shadow-[0_4px_16px_rgba(37,99,235,0.4)]' : 'bg-card shadow-[0_2px_8px_rgba(0,0,0,0.1)]'}
              border border-border/50
              transition-all duration-300
            `}>
              <MapPin className={`h-4 w-4 ${isHovered ? 'text-primary-foreground' : 'text-primary'}`} />
            </div>
            {isHovered && (
              <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 whitespace-nowrap">
                <div className="bg-card px-2.5 py-1 rounded-lg shadow-[0_4px_12px_rgba(0,0,0,0.1)] border border-border/50">
                  <p className="text-[10px] font-semibold text-foreground">${job.price}</p>
                </div>
              </div>
            )}
          </button>
        )
      })}

      {/* Location Button */}
      <button className="absolute bottom-3 right-3 p-2.5 bg-card rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.08)] border border-border/50 hover:shadow-[0_4px_12px_rgba(0,0,0,0.12)] transition-all duration-300 active:scale-95">
        <Navigation className="h-4 w-4 text-foreground" />
      </button>

      {/* Map Label */}
      <div className="absolute top-3 left-3">
        <div className="bg-card/90 backdrop-blur-sm px-3 py-1.5 rounded-lg border border-border/50">
          <p className="text-[10px] font-medium text-muted-foreground">Casablanca</p>
        </div>
      </div>
    </div>
  )
}
