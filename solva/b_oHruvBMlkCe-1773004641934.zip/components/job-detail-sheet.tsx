"use client"

import { useState } from "react"
import { X, MapPin, Clock, Star, CheckCircle2, MessageCircle, DollarSign } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { Job, User } from "@/lib/types"

interface JobDetailSheetProps {
  job: Job | null
  onClose: () => void
  user?: User | null
  onMakeBid?: () => void
}

export function JobDetailSheet({ job, onClose, user, onMakeBid }: JobDetailSheetProps) {
  const [isAccepting, setIsAccepting] = useState(false)
  const [accepted, setAccepted] = useState(false)

  if (!job) return null

  const handleAccept = async () => {
    setIsAccepting(true)
    await new Promise(resolve => setTimeout(resolve, 1500))
    setIsAccepting(false)
    setAccepted(true)
  }

  const handleClose = () => {
    setAccepted(false)
    onClose()
  }

  const isProfessional = user?.role === "professional"

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-foreground/20 backdrop-blur-sm z-40 transition-opacity duration-300"
        onClick={handleClose}
      />

      {/* Sheet */}
      <div className="fixed inset-x-0 bottom-0 z-50 mx-auto max-w-md">
        <div className="bg-card rounded-t-3xl shadow-[0_-8px_32px_rgba(0,0,0,0.12)] border-t border-border/50 animate-in slide-in-from-bottom duration-300">
          {/* Handle */}
          <div className="flex justify-center pt-3 pb-2">
            <div className="w-10 h-1 bg-muted-foreground/20 rounded-full" />
          </div>

          {/* Close Button */}
          <button
            onClick={handleClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-muted hover:bg-muted/80 transition-colors"
          >
            <X className="h-4 w-4 text-muted-foreground" />
          </button>

          <div className="px-6 pb-8 pt-2 max-h-[80vh] overflow-y-auto">
            {/* Category Badge */}
            <span className="inline-block text-[10px] font-semibold uppercase tracking-wider text-primary bg-primary/10 px-2.5 py-1 rounded-md mb-3">
              {job.category}
            </span>

            {/* Title & Price */}
            <div className="flex items-start justify-between gap-4 mb-6">
              <h2 className="text-xl font-bold text-foreground tracking-tight">{job.title}</h2>
              <div className="text-right shrink-0">
                <p className="text-2xl font-bold text-foreground">${job.price}</p>
                <p className="text-xs text-muted-foreground">presupuesto</p>
              </div>
            </div>

            {/* Meta Info */}
            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4" />
                <span>{job.distance}</span>
              </div>
              <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                <Clock className="h-4 w-4" />
                <span>{job.estimatedDuration}</span>
              </div>
            </div>

            {/* Description */}
            <div className="mb-6">
              <h3 className="text-sm font-semibold text-foreground mb-2">Descripción</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{job.description}</p>
            </div>

            {/* Requirements */}
            {job.requirements && job.requirements.length > 0 && (
              <div className="mb-6">
                <h3 className="text-sm font-semibold text-foreground mb-3">Requisitos</h3>
                <div className="space-y-2">
                  {job.requirements.map((req, index) => (
                    <div key={index} className="flex items-center gap-2.5">
                      <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                        <CheckCircle2 className="h-3 w-3 text-primary" />
                      </div>
                      <span className="text-sm text-muted-foreground">{req}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Posted By */}
            <div className="p-4 bg-secondary/50 rounded-2xl mb-6">
              <div className="flex items-center gap-3">
                <img
                  src={job.postedBy.avatar}
                  alt={job.postedBy.name}
                  className="w-12 h-12 rounded-full object-cover ring-2 ring-card"
                />
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-foreground text-sm">{job.postedBy.name}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <div className="flex items-center gap-1">
                      <Star className="h-3.5 w-3.5 text-amber-500 fill-amber-500" />
                      <span className="text-xs font-medium text-foreground">{job.postedBy.rating}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">•</span>
                    <span className="text-xs text-muted-foreground">{job.postedBy.jobsCompleted} trabajos</span>
                  </div>
                </div>
                <button className="p-2.5 rounded-xl bg-card hover:bg-muted transition-colors shadow-sm">
                  <MessageCircle className="h-4 w-4 text-muted-foreground" />
                </button>
              </div>
            </div>

            {/* Location */}
            <div className="mb-8">
              <h3 className="text-sm font-semibold text-foreground mb-2">Ubicación</h3>
              <p className="text-sm text-muted-foreground">{job.location.address}</p>
            </div>

            {/* Actions */}
            {accepted ? (
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/30 rounded-2xl border border-emerald-200 dark:border-emerald-800">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-emerald-500 flex items-center justify-center">
                    <CheckCircle2 className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <p className="font-semibold text-emerald-900 dark:text-emerald-100">
                      {isProfessional ? "Oferta enviada" : "Trabajo aceptado"}
                    </p>
                    <p className="text-sm text-emerald-700 dark:text-emerald-300">
                      {isProfessional ? "El cliente revisará tu oferta" : "El cliente ha sido notificado"}
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  className="flex-1 h-12 rounded-xl border-border text-foreground hover:bg-muted"
                  onClick={handleClose}
                >
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Contactar
                </Button>
                {isProfessional ? (
                  <Button
                    className="flex-1 h-12 rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_4px_12px_rgba(37,99,235,0.3)]"
                    onClick={() => {
                      if (onMakeBid) {
                        onMakeBid()
                        handleClose()
                      }
                    }}
                  >
                    <DollarSign className="h-4 w-4 mr-2" />
                    Hacer oferta
                  </Button>
                ) : (
                  <Button
                    className="flex-1 h-12 rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_4px_12px_rgba(37,99,235,0.3)]"
                    onClick={handleAccept}
                    disabled={isAccepting}
                  >
                    {isAccepting ? (
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                        <span>Aceptando...</span>
                      </div>
                    ) : (
                      <>
                        <CheckCircle2 className="h-4 w-4 mr-2" />
                        Aceptar trabajo
                      </>
                    )}
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  )
}
