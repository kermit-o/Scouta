"use client"

import { useState } from "react"
import { Search, Star, CheckCircle2, MapPin, SlidersHorizontal } from "lucide-react"
import { professionals } from "@/lib/mock-data"

const categories = ["All", "Cleaning", "Plumbing", "Electrical", "Moving", "Painting"]

export function SearchScreen() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeCategory, setActiveCategory] = useState("All")

  return (
    <div className="px-6 pt-14">
      {/* Header */}
      <header className="mb-6">
        <h1 className="text-2xl font-semibold text-foreground tracking-tight">Find Professionals</h1>
        <p className="text-sm text-muted-foreground mt-1">Discover trusted service providers</p>
      </header>

      {/* Search Bar */}
      <div className="relative mb-6">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <input
          type="text"
          placeholder="Search services or professionals..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full h-12 pl-11 pr-12 bg-card rounded-xl border border-border/50 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary/50 transition-all shadow-[0_2px_8px_rgba(0,0,0,0.04)]"
        />
        <button className="absolute right-2 top-1/2 -translate-y-1/2 p-2 hover:bg-muted rounded-lg transition-colors">
          <SlidersHorizontal className="h-4 w-4 text-muted-foreground" />
        </button>
      </div>

      {/* Categories */}
      <div className="mb-6 -mx-6 px-6">
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`
                px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all duration-300
                ${activeCategory === category
                  ? "bg-primary text-primary-foreground shadow-[0_4px_12px_rgba(37,99,235,0.3)]"
                  : "bg-card text-muted-foreground border border-border/50 hover:border-border hover:bg-muted"
                }
              `}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-foreground">Top Rated</h2>
          <span className="text-xs text-muted-foreground">{professionals.length} available</span>
        </div>

        {professionals.map((pro) => (
          <button
            key={pro.id}
            className="w-full p-4 bg-card rounded-2xl border border-border/50 text-left shadow-[0_2px_8px_rgba(0,0,0,0.04)] transition-all duration-300 hover:shadow-[0_8px_24px_rgba(0,0,0,0.08)] hover:border-border active:scale-[0.99]"
          >
            <div className="flex items-center gap-4">
              <div className="relative">
                <img
                  src={pro.avatar}
                  alt={pro.name}
                  className="w-14 h-14 rounded-2xl object-cover"
                />
                {pro.verified && (
                  <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-primary rounded-full flex items-center justify-center ring-2 ring-card">
                    <CheckCircle2 className="h-3 w-3 text-primary-foreground" />
                  </div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold text-foreground text-sm">{pro.name}</h3>
                  {pro.verified && (
                    <span className="text-[9px] font-semibold uppercase tracking-wider text-primary bg-primary/10 px-1.5 py-0.5 rounded">
                      Verified
                    </span>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mb-2">{pro.profession}</p>
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1">
                    <Star className="h-3.5 w-3.5 text-amber-500 fill-amber-500" />
                    <span className="text-xs font-semibold text-foreground">{pro.rating}</span>
                  </div>
                  <span className="text-xs text-muted-foreground">{pro.jobsCompleted} jobs</span>
                </div>
              </div>
              <div className="text-right shrink-0">
                <p className="text-lg font-bold text-foreground">${pro.hourlyRate}</p>
                <p className="text-[10px] text-muted-foreground">/hour</p>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}
