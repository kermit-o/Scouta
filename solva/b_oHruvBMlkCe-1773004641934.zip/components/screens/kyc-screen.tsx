"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { 
  ArrowLeft, 
  Camera,
  FileText,
  CheckCircle2,
  Clock,
  XCircle,
  Shield,
  ChevronRight,
  Upload,
  User,
  CreditCard,
  Home
} from "lucide-react"
import type { User } from "@/lib/types"

interface KYCScreenProps {
  user: User | null
  onBack: () => void
  onSubmit: () => void
}

type DocumentType = "id" | "selfie" | "address"

interface Document {
  type: DocumentType
  status: "pending" | "uploaded" | "verified" | "rejected"
  file?: string
}

export function KYCScreen({ user, onBack, onSubmit }: KYCScreenProps) {
  const [step, setStep] = useState<"intro" | "documents" | "submitted">("intro")
  const [documents, setDocuments] = useState<Document[]>([
    { type: "id", status: "pending" },
    { type: "selfie", status: "pending" },
    { type: "address", status: "pending" },
  ])
  const [isLoading, setIsLoading] = useState(false)

  const documentLabels: Record<DocumentType, { title: string; description: string; icon: React.ElementType }> = {
    id: { 
      title: "Documento de identidad", 
      description: "INE, pasaporte o licencia de conducir",
      icon: CreditCard
    },
    selfie: { 
      title: "Selfie con documento", 
      description: "Foto sosteniendo tu identificación",
      icon: User
    },
    address: { 
      title: "Comprobante de domicilio", 
      description: "Recibo de luz, agua o estado de cuenta",
      icon: Home
    },
  }

  const handleUpload = (type: DocumentType) => {
    setDocuments(docs => 
      docs.map(d => 
        d.type === type 
          ? { ...d, status: "uploaded", file: `/placeholder.svg?height=200&width=200&text=${type}` }
          : d
      )
    )
  }

  const handleSubmit = async () => {
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setIsLoading(false)
    setStep("submitted")
  }

  const allUploaded = documents.every(d => d.status === "uploaded")

  if (step === "submitted") {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <div className="flex-1 flex flex-col items-center justify-center px-8">
          <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mb-6">
            <Clock className="w-10 h-10 text-primary" />
          </div>
          <h1 className="text-2xl font-semibold text-foreground text-center mb-2">
            Documentos enviados
          </h1>
          <p className="text-muted-foreground text-center mb-2">
            Estamos verificando tu información
          </p>
          <p className="text-sm text-muted-foreground text-center mb-8">
            Este proceso puede tomar entre 24-48 horas
          </p>
          
          <div className="w-full max-w-sm space-y-3 mb-8">
            {documents.map((doc) => {
              const { title, icon: Icon } = documentLabels[doc.type]
              return (
                <div key={doc.type} className="flex items-center gap-3 p-4 bg-card rounded-xl border border-border/50">
                  <Icon className="w-5 h-5 text-muted-foreground" />
                  <span className="flex-1 text-foreground">{title}</span>
                  <Clock className="w-4 h-4 text-amber-500" />
                </div>
              )
            })}
          </div>

          <Button
            onClick={onSubmit}
            className="w-full max-w-sm h-14 rounded-xl text-base font-semibold shadow-lg shadow-primary/20"
          >
            Volver al perfil
          </Button>
        </div>
      </div>
    )
  }

  if (step === "documents") {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-xl border-b border-border/50">
          <div className="flex items-center gap-4 px-6 py-4">
            <button
              onClick={() => setStep("intro")}
              className="w-10 h-10 rounded-full bg-card border border-border/50 flex items-center justify-center shadow-sm"
            >
              <ArrowLeft className="w-5 h-5 text-foreground" />
            </button>
            <div className="flex-1">
              <h1 className="text-lg font-semibold text-foreground">Verificación KYC</h1>
              <p className="text-sm text-muted-foreground">
                {documents.filter(d => d.status === "uploaded").length} de 3 documentos
              </p>
            </div>
          </div>
        </div>

        <div className="flex-1 px-6 py-6 space-y-4">
          {documents.map((doc) => {
            const { title, description, icon: Icon } = documentLabels[doc.type]
            return (
              <div 
                key={doc.type}
                className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm"
              >
                <div className="flex items-start gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                    doc.status === "uploaded" ? "bg-emerald-500/10" : "bg-muted"
                  }`}>
                    <Icon className={`w-6 h-6 ${
                      doc.status === "uploaded" ? "text-emerald-600" : "text-muted-foreground"
                    }`} />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-foreground mb-1">{title}</h4>
                    <p className="text-sm text-muted-foreground mb-3">{description}</p>
                    
                    {doc.status === "pending" ? (
                      <Button
                        variant="outline"
                        onClick={() => handleUpload(doc.type)}
                        className="h-10 rounded-xl border-border/50"
                      >
                        <Upload className="w-4 h-4 mr-2" />
                        Subir documento
                      </Button>
                    ) : doc.status === "uploaded" ? (
                      <div className="flex items-center gap-2 text-emerald-600">
                        <CheckCircle2 className="w-4 h-4" />
                        <span className="text-sm font-medium">Documento subido</span>
                      </div>
                    ) : doc.status === "verified" ? (
                      <div className="flex items-center gap-2 text-emerald-600">
                        <CheckCircle2 className="w-4 h-4" />
                        <span className="text-sm font-medium">Verificado</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 text-destructive">
                        <XCircle className="w-4 h-4" />
                        <span className="text-sm font-medium">Rechazado - Subir de nuevo</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )
          })}

          {/* Tips */}
          <div className="bg-muted/50 rounded-2xl p-4 space-y-2">
            <h4 className="text-sm font-medium text-foreground">Consejos para subir documentos:</h4>
            <ul className="text-xs text-muted-foreground space-y-1">
              <li>- Asegúrate de que el documento sea legible</li>
              <li>- Evita reflejos y sombras</li>
              <li>- El documento debe estar completo en la foto</li>
              <li>- Para la selfie, muestra tu rostro claramente</li>
            </ul>
          </div>
        </div>

        <div className="sticky bottom-0 bg-background/80 backdrop-blur-xl border-t border-border/50 px-6 py-4">
          <Button
            onClick={handleSubmit}
            disabled={!allUploaded || isLoading}
            className="w-full h-14 rounded-xl text-base font-semibold shadow-lg shadow-primary/20"
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
            ) : (
              "Enviar para verificación"
            )}
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-xl border-b border-border/50">
        <div className="flex items-center gap-4 px-6 py-4">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-card border border-border/50 flex items-center justify-center shadow-sm"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
          <h1 className="text-lg font-semibold text-foreground">Verificación KYC</h1>
        </div>
      </div>

      <div className="flex-1 px-6 py-6 space-y-6">
        {/* Hero */}
        <div className="text-center py-6">
          <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
            <Shield className="w-10 h-10 text-primary" />
          </div>
          <h2 className="text-2xl font-semibold text-foreground mb-2">
            Verifica tu identidad
          </h2>
          <p className="text-muted-foreground">
            Completa la verificación para acceder a todas las funciones de Solva
          </p>
        </div>

        {/* Benefits */}
        <div className="space-y-3">
          {[
            { icon: CheckCircle2, title: "Mayor confianza", description: "Los usuarios verificados generan más confianza" },
            { icon: Shield, title: "Protección completa", description: "Accede a la Garantía Solva y protección de pagos" },
            { icon: FileText, title: "Límites más altos", description: "Aumenta tus límites de transacción" },
          ].map((benefit, i) => (
            <div key={i} className="flex items-start gap-4 p-4 bg-card rounded-2xl border border-border/50">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                <benefit.icon className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h4 className="font-medium text-foreground">{benefit.title}</h4>
                <p className="text-sm text-muted-foreground">{benefit.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* What you need */}
        <div className="bg-muted/50 rounded-2xl p-5">
          <h4 className="font-semibold text-foreground mb-3">Lo que necesitarás:</h4>
          <ul className="space-y-2">
            {[
              "Documento de identidad válido (INE, pasaporte)",
              "Una selfie sosteniendo el documento",
              "Comprobante de domicilio reciente",
            ].map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <span className="text-xs font-medium text-primary">{i + 1}</span>
                </div>
                {item}
              </li>
            ))}
          </ul>
        </div>

        {/* Privacy Note */}
        <div className="flex items-start gap-3 p-4 rounded-xl bg-primary/5 border border-primary/20">
          <Shield className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
          <p className="text-sm text-muted-foreground">
            Tu información está protegida con encriptación de nivel bancario y nunca será compartida con terceros.
          </p>
        </div>
      </div>

      <div className="sticky bottom-0 bg-background/80 backdrop-blur-xl border-t border-border/50 px-6 py-4">
        <Button
          onClick={() => setStep("documents")}
          className="w-full h-14 rounded-xl text-base font-semibold shadow-lg shadow-primary/20"
        >
          Comenzar verificación
          <ChevronRight className="w-5 h-5 ml-2" />
        </Button>
      </div>
    </div>
  )
}
