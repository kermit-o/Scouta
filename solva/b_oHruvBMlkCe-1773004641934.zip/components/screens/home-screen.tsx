"use client"

import { MapPin, ChevronRight, Star, Clock, Plus } from "lucide-react"
import { nearbyJobs } from "@/lib/mock-data"
import type { Job, User } from "@/lib/types"
import { JobMap } from "@/components/job-map"

interface HomeScreenProps {
  onJobSelect: (job: Job) => void
  onNavigate: (screen: string) => void
  user: User | null
}

export function HomeScreen({ onJobSelect, onNavigate, user }: HomeScreenProps) {
  const greeting = () => {
    const hour = new Date().getHours()
    if (hour < 12) return "Buenos días"
    if (hour < 18) return "Buenas tardes"
    return "Buenas noches"
  }

  return (
    <div className="px-6 pt-14">
      {/* Header */}
      <header className="mb-8">
        <p className="text-sm font-medium text-muted-foreground tracking-wide">{greeting()}</p>
        <h1 className="text-2xl font-semibold text-foreground tracking-tight mt-1">
          Hola, {user?.name?.split(" ")[0] || "Usuario"}
        </h1>
      </header>

      {/* Map Section */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground tracking-tight">Trabajos cercanos</h2>
          <button 
            onClick={() => onNavigate("jobs")}
            className="flex items-center gap-1 text-sm font-medium text-primary hover:text-primary/80 transition-colors"
          >
            Ver todos
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
        <JobMap jobs={nearbyJobs} onJobSelect={onJobSelect} />
      </section>

      {/* Quick Actions */}
      <section className="mb-8">
        <div className="grid grid-cols-2 gap-4">
          {user?.role === "client" ? (
            <>
              <button 
                onClick={() => onNavigate("post-job")}
                className="group p-5 bg-primary rounded-2xl text-left transition-all duration-300 hover:shadow-[0_8px_24px_rgba(37,99,235,0.25)] active:scale-[0.98]"
              >
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center mb-4">
                  <Plus className="h-5 w-5 text-primary-foreground" />
                </div>
                <p className="text-sm font-semibold text-primary-foreground">Publicar trabajo</p>
                <p className="text-xs text-primary-foreground/70 mt-1">Encuentra profesionales</p>
              </button>
              <button 
                onClick={() => onNavigate("search")}
                className="group p-5 bg-card rounded-2xl border border-border/50 text-left shadow-[0_2px_8px_rgba(0,0,0,0.04)] transition-all duration-300 hover:shadow-[0_8px_24px_rgba(0,0,0,0.08)] hover:border-border active:scale-[0.98]"
              >
                <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center mb-4">
                  <Star className="h-5 w-5 text-foreground" />
                </div>
                <p className="text-sm font-semibold text-foreground">Buscar servicios</p>
                <p className="text-xs text-muted-foreground mt-1">Explora categorías</p>
              </button>
            </>
          ) : (
            <>
              <button 
                onClick={() => onNavigate("jobs")}
                className="group p-5 bg-primary rounded-2xl text-left transition-all duration-300 hover:shadow-[0_8px_24px_rgba(37,99,235,0.25)] active:scale-[0.98]"
              >
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center mb-4">
                  <MapPin className="h-5 w-5 text-primary-foreground" />
                </div>
                <p className="text-sm font-semibold text-primary-foreground">Buscar trabajos</p>
                <p className="text-xs text-primary-foreground/70 mt-1">Encuentra oportunidades</p>
              </button>
              <button 
                onClick={() => onNavigate("profile")}
                className="group p-5 bg-card rounded-2xl border border-border/50 text-left shadow-[0_2px_8px_rgba(0,0,0,0.04)] transition-all duration-300 hover:shadow-[0_8px_24px_rgba(0,0,0,0.08)] hover:border-border active:scale-[0.98]"
              >
                <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center mb-4">
                  <Star className="h-5 w-5 text-foreground" />
                </div>
                <p className="text-sm font-semibold text-foreground">Mi perfil</p>
                <p className="text-xs text-muted-foreground mt-1">Ver reseñas y estadísticas</p>
              </button>
            </>
          )}
        </div>
      </section>

      {/* Available Jobs */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground tracking-tight">
            {user?.role === "client" ? "Tus trabajos activos" : "Trabajos disponibles"}
          </h2>
          <span className="text-xs font-medium text-muted-foreground bg-secondary px-2.5 py-1 rounded-full">
            {nearbyJobs.length} cercanos
          </span>
        </div>
        <div className="space-y-3">
          {nearbyJobs.slice(0, 3).map((job) => (
            <button
              key={job.id}
              onClick={() => onJobSelect(job)}
              className="w-full p-4 bg-card rounded-2xl border border-border/50 text-left shadow-[0_2px_8px_rgba(0,0,0,0.04)] transition-all duration-300 hover:shadow-[0_8px_24px_rgba(0,0,0,0.08)] hover:border-border active:scale-[0.99]"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-primary bg-primary/10 px-2 py-0.5 rounded-md">
                      {job.category}
                    </span>
                  </div>
                  <h3 className="font-semibold text-foreground text-sm mb-2 truncate">{job.title}</h3>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <MapPin className="h-3.5 w-3.5" />
                      {job.distance}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5" />
                      {job.estimatedDuration}
                    </span>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-lg font-bold text-foreground">${job.price}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{job.postedAt}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </section>
    </div>
  )
}
