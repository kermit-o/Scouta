"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { 
  ArrowLeft, 
  AlertTriangle,
  Camera,
  X,
  CheckCircle2,
  Clock,
  MessageCircle,
  Shield
} from "lucide-react"
import type { Contract } from "@/lib/types"

interface DisputeScreenProps {
  contract: Contract | null
  onBack: () => void
  onSubmit: () => void
}

type DisputeReason = "quality" | "incomplete" | "noShow" | "damage" | "other"

const DISPUTE_REASONS: { id: DisputeReason; title: string; description: string }[] = [
  { id: "quality", title: "Calidad insatisfactoria", description: "El trabajo no cumple con lo acordado" },
  { id: "incomplete", title: "Trabajo incompleto", description: "El profesional no terminó el trabajo" },
  { id: "noShow", title: "No se presentó", description: "El profesional no llegó a la cita" },
  { id: "damage", title: "Daños causados", description: "Se causaron daños durante el trabajo" },
  { id: "other", title: "Otro motivo", description: "Describe tu situación" },
]

export function DisputeScreen({ contract, onBack, onSubmit }: DisputeScreenProps) {
  const [step, setStep] = useState<"reason" | "details" | "submitted">("reason")
  const [selectedReason, setSelectedReason] = useState<DisputeReason | null>(null)
  const [description, setDescription] = useState("")
  const [photos, setPhotos] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(false)

  const handleAddPhoto = () => {
    setPhotos([...photos, `/placeholder.svg?height=200&width=200&text=Evidence${photos.length + 1}`])
  }

  const handleRemovePhoto = (index: number) => {
    setPhotos(photos.filter((_, i) => i !== index))
  }

  const handleSubmit = async () => {
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setIsLoading(false)
    setStep("submitted")
  }

  if (step === "submitted") {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <div className="flex-1 flex flex-col items-center justify-center px-8">
          <div className="w-20 h-20 rounded-full bg-amber-500/20 flex items-center justify-center mb-6">
            <Clock className="w-10 h-10 text-amber-600" />
          </div>
          <h1 className="text-2xl font-semibold text-foreground text-center mb-2">
            Disputa enviada
          </h1>
          <p className="text-muted-foreground text-center mb-6">
            Nuestro equipo revisará tu caso en las próximas 24-48 horas
          </p>
          
          <div className="w-full max-w-sm bg-card rounded-2xl border border-border/50 p-4 mb-8">
            <div className="flex items-center gap-3 mb-3">
              <MessageCircle className="w-5 h-5 text-primary" />
              <span className="font-medium text-foreground">¿Qué sigue?</span>
            </div>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>1. Revisaremos la evidencia proporcionada</li>
              <li>2. Contactaremos a ambas partes</li>
              <li>3. Tomaremos una decisión justa</li>
              <li>4. Te notificaremos el resultado</li>
            </ul>
          </div>

          <Button
            onClick={onSubmit}
            className="w-full max-w-sm h-14 rounded-xl text-base font-semibold shadow-lg shadow-primary/20"
          >
            Volver a mis trabajos
          </Button>
        </div>
      </div>
    )
  }

  if (step === "details") {
    const reason = DISPUTE_REASONS.find(r => r.id === selectedReason)
    
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-xl border-b border-border/50">
          <div className="flex items-center gap-4 px-6 py-4">
            <button
              onClick={() => setStep("reason")}
              className="w-10 h-10 rounded-full bg-card border border-border/50 flex items-center justify-center shadow-sm"
            >
              <ArrowLeft className="w-5 h-5 text-foreground" />
            </button>
            <div className="flex-1">
              <h1 className="text-lg font-semibold text-foreground">Detalles de la disputa</h1>
              <p className="text-sm text-muted-foreground">{reason?.title}</p>
            </div>
          </div>
        </div>

        <div className="flex-1 px-6 py-6 space-y-6">
          {/* Description */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Describe el problema
            </label>
            <Textarea
              placeholder="Explica en detalle qué sucedió y por qué estás abriendo esta disputa..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="min-h-40 bg-card border-border/50 rounded-xl text-base shadow-sm resize-none"
            />
            <p className="text-xs text-muted-foreground">
              {description.length}/1000 caracteres
            </p>
          </div>

          {/* Evidence Photos */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-foreground">
              Evidencia (fotos o capturas)
            </label>
            <p className="text-xs text-muted-foreground">
              Adjunta fotos que respalden tu caso
            </p>
            <div className="flex gap-3 overflow-x-auto pb-2">
              {photos.map((photo, index) => (
                <div key={index} className="relative flex-shrink-0">
                  <img
                    src={photo}
                    alt={`Evidencia ${index + 1}`}
                    className="w-20 h-20 rounded-xl object-cover"
                  />
                  <button
                    onClick={() => handleRemovePhoto(index)}
                    className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
              {photos.length < 5 && (
                <button
                  onClick={handleAddPhoto}
                  className="w-20 h-20 rounded-xl border-2 border-dashed border-border flex flex-col items-center justify-center gap-1 hover:border-primary hover:bg-primary/5 transition-colors flex-shrink-0"
                >
                  <Camera className="w-5 h-5 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">Añadir</span>
                </button>
              )}
            </div>
          </div>

          {/* Info */}
          <div className="bg-amber-500/10 rounded-2xl p-4 border border-amber-500/20">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-foreground text-sm mb-1">Importante</p>
                <p className="text-xs text-muted-foreground">
                  Las disputas falsas o malintencionadas pueden resultar en la suspensión de tu cuenta. 
                  Asegúrate de proporcionar información veraz.
                </p>
              </div>
            </div>
          </div>

          {/* Guarantee */}
          <div className="flex items-start gap-3 p-4 rounded-xl bg-primary/5 border border-primary/20">
            <Shield className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-foreground text-sm mb-1">Garantía Solva</p>
              <p className="text-xs text-muted-foreground">
                Tu pago está protegido en escrow hasta que se resuelva la disputa.
              </p>
            </div>
          </div>
        </div>

        <div className="sticky bottom-0 bg-background/80 backdrop-blur-xl border-t border-border/50 px-6 py-4">
          <Button
            onClick={handleSubmit}
            disabled={!description || isLoading}
            className="w-full h-14 rounded-xl text-base font-semibold bg-amber-600 hover:bg-amber-700 shadow-lg shadow-amber-600/20"
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              "Enviar disputa"
            )}
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-xl border-b border-border/50">
        <div className="flex items-center gap-4 px-6 py-4">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-card border border-border/50 flex items-center justify-center shadow-sm"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
          <h1 className="text-lg font-semibold text-foreground">Abrir disputa</h1>
        </div>
      </div>

      <div className="flex-1 px-6 py-6 space-y-6">
        {/* Warning */}
        <div className="bg-amber-500/10 rounded-2xl p-4 border border-amber-500/20">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-foreground text-sm mb-1">Antes de continuar</p>
              <p className="text-xs text-muted-foreground">
                Te recomendamos intentar resolver el problema directamente con el profesional antes de abrir una disputa.
              </p>
            </div>
          </div>
        </div>

        {/* Reason Selection */}
        <div className="space-y-3">
          <h4 className="font-semibold text-foreground">¿Cuál es el motivo?</h4>
          {DISPUTE_REASONS.map((reason) => (
            <button
              key={reason.id}
              onClick={() => setSelectedReason(reason.id)}
              className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 text-left transition-all ${
                selectedReason === reason.id
                  ? "border-amber-500 bg-amber-500/5 shadow-sm"
                  : "border-border/50 bg-card hover:border-border"
              }`}
            >
              <div className="flex-1">
                <p className="font-medium text-foreground">{reason.title}</p>
                <p className="text-sm text-muted-foreground">{reason.description}</p>
              </div>
              {selectedReason === reason.id && (
                <CheckCircle2 className="w-5 h-5 text-amber-600 flex-shrink-0" />
              )}
            </button>
          ))}
        </div>
      </div>

      <div className="sticky bottom-0 bg-background/80 backdrop-blur-xl border-t border-border/50 px-6 py-4">
        <Button
          onClick={() => setStep("details")}
          disabled={!selectedReason}
          className="w-full h-14 rounded-xl text-base font-semibold bg-amber-600 hover:bg-amber-700 shadow-lg shadow-amber-600/20"
        >
          Continuar
        </Button>
      </div>
    </div>
  )
}
