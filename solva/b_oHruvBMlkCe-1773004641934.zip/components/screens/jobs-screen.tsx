"use client"

import { useState } from "react"
import { MapPin, Clock, ChevronRight, Eye } from "lucide-react"
import { nearbyJobs } from "@/lib/mock-data"
import type { Job, User } from "@/lib/types"
import { Button } from "@/components/ui/button"

interface JobsScreenProps {
  onJobSelect: (job: Job) => void
  user: User | null
  onNavigate: (screen: string) => void
}

const tabs = ["Disponibles", "Mis trabajos"]

export function JobsScreen({ onJobSelect, user, onNavigate }: JobsScreenProps) {
  const [activeTab, setActiveTab] = useState("Disponibles")

  const myJobs = nearbyJobs.slice(0, 3).map((job, i) => ({
    ...job,
    status: i === 0 ? "in-progress" : i === 1 ? "pending-bids" : "completed",
    bidsCount: i === 1 ? 3 : 0
  }))

  return (
    <div className="px-6 pt-14">
      {/* Header */}
      <header className="mb-6">
        <h1 className="text-2xl font-semibold text-foreground tracking-tight">Trabajos</h1>
        <p className="text-sm text-muted-foreground mt-1">
          {user?.role === "client" ? "Gestiona tus publicaciones" : "Encuentra oportunidades"}
        </p>
      </header>

      {/* Tabs */}
      <div className="flex gap-2 mb-6">
        {tabs.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`
              flex-1 py-3 rounded-xl text-sm font-semibold transition-all duration-300
              ${activeTab === tab
                ? "bg-primary text-primary-foreground shadow-[0_4px_12px_rgba(37,99,235,0.3)]"
                : "bg-card text-muted-foreground border border-border/50 hover:bg-muted"
              }
            `}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Content */}
      {activeTab === "Disponibles" ? (
        <div className="space-y-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold text-foreground">{nearbyJobs.length} trabajos cercanos</span>
            <button className="text-sm font-medium text-primary flex items-center gap-1 hover:text-primary/80 transition-colors">
              Filtrar
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
          {nearbyJobs.map((job) => (
            <button
              key={job.id}
              onClick={() => onJobSelect(job)}
              className="w-full p-4 bg-card rounded-2xl border border-border/50 text-left shadow-[0_2px_8px_rgba(0,0,0,0.04)] transition-all duration-300 hover:shadow-[0_8px_24px_rgba(0,0,0,0.08)] hover:border-border active:scale-[0.99]"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-primary bg-primary/10 px-2 py-0.5 rounded-md">
                      {job.category}
                    </span>
                  </div>
                  <h3 className="font-semibold text-foreground text-sm mb-2">{job.title}</h3>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <MapPin className="h-3.5 w-3.5" />
                      {job.distance}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5" />
                      {job.estimatedDuration}
                    </span>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-lg font-bold text-foreground">${job.price}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{job.postedAt}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          {myJobs.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground mb-4">No tienes trabajos activos</p>
              {user?.role === "client" && (
                <Button onClick={() => onNavigate("post-job")}>
                  Publicar trabajo
                </Button>
              )}
            </div>
          ) : (
            myJobs.map((job) => (
              <div
                key={job.id}
                className="p-4 bg-card rounded-2xl border border-border/50 shadow-[0_2px_8px_rgba(0,0,0,0.04)]"
              >
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className={`
                        text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-md
                        ${job.status === "in-progress" 
                          ? "text-amber-600 bg-amber-100 dark:text-amber-400 dark:bg-amber-950" 
                          : job.status === "pending-bids"
                          ? "text-primary bg-primary/10"
                          : "text-emerald-600 bg-emerald-100 dark:text-emerald-400 dark:bg-emerald-950"
                        }
                      `}>
                        {job.status === "in-progress" ? "En progreso" : 
                         job.status === "pending-bids" ? `${job.bidsCount} ofertas` : 
                         "Completado"}
                      </span>
                    </div>
                    <h3 className="font-semibold text-foreground text-sm mb-2">{job.title}</h3>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <MapPin className="h-3.5 w-3.5" />
                        {job.location.address}
                      </span>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-lg font-bold text-foreground">${job.price}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  {job.status === "pending-bids" && user?.role === "client" ? (
                    <Button 
                      size="sm" 
                      className="flex-1 rounded-xl"
                      onClick={() => {
                        onJobSelect(job)
                        onNavigate("bid-detail")
                      }}
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      Ver ofertas ({job.bidsCount})
                    </Button>
                  ) : job.status === "in-progress" ? (
                    <Button 
                      size="sm" 
                      className="flex-1 rounded-xl"
                      onClick={() => onNavigate("contract")}
                    >
                      Ver contrato
                    </Button>
                  ) : (
                    <Button 
                      size="sm" 
                      variant="outline"
                      className="flex-1 rounded-xl"
                      onClick={() => onNavigate("review")}
                    >
                      Dejar reseña
                    </Button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  )
}
