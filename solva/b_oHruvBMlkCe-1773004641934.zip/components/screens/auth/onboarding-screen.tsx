"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ArrowRight, Briefcase, UserCircle, Check, MapPin, ChevronRight } from "lucide-react"
import { COUNTRIES } from "@/lib/types"

interface OnboardingScreenProps {
  onComplete: (data: { country: string; role: "client" | "professional" }) => void
}

export function OnboardingScreen({ onComplete }: OnboardingScreenProps) {
  const [step, setStep] = useState<1 | 2>(1)
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null)
  const [selectedRole, setSelectedRole] = useState<"client" | "professional" | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const handleComplete = async () => {
    if (!selectedCountry || !selectedRole) return
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsLoading(false)
    onComplete({ country: selectedCountry, role: selectedRole })
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Progress */}
      <div className="px-8 pt-16 pb-6">
        <div className="flex gap-2">
          <div className="h-1 flex-1 rounded-full bg-primary" />
          <div className={`h-1 flex-1 rounded-full transition-colors ${step >= 2 ? "bg-primary" : "bg-border"}`} />
        </div>
        <p className="text-sm text-muted-foreground mt-4">
          Paso {step} de 2
        </p>
      </div>

      {step === 1 ? (
        /* Country Selection */
        <div className="flex-1 flex flex-col px-8 pb-8">
          <div className="mb-8">
            <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-6">
              <MapPin className="w-7 h-7 text-primary" />
            </div>
            <h1 className="text-3xl font-semibold text-foreground tracking-tight mb-2">
              ¿Dónde te encuentras?
            </h1>
            <p className="text-muted-foreground text-lg">
              Selecciona tu país para personalizar tu experiencia
            </p>
          </div>

          <div className="flex-1 space-y-3">
            {COUNTRIES.map((country) => (
              <button
                key={country.code}
                onClick={() => setSelectedCountry(country.code)}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 transition-all ${
                  selectedCountry === country.code
                    ? "border-primary bg-primary/5 shadow-sm"
                    : "border-border/50 bg-card hover:border-border hover:bg-muted/30"
                }`}
              >
                <span className="text-3xl">{country.flag}</span>
                <div className="flex-1 text-left">
                  <p className="font-medium text-foreground">{country.name}</p>
                  <p className="text-sm text-muted-foreground">{country.currency}</p>
                </div>
                {selectedCountry === country.code && (
                  <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                    <Check className="w-4 h-4 text-primary-foreground" />
                  </div>
                )}
              </button>
            ))}
          </div>

          <div className="pt-6">
            <Button
              onClick={() => setStep(2)}
              disabled={!selectedCountry}
              className="w-full h-14 rounded-xl text-base font-semibold shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 transition-all"
            >
              Continuar
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </div>
      ) : (
        /* Role Selection */
        <div className="flex-1 flex flex-col px-8 pb-8">
          <div className="mb-8">
            <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-6">
              <UserCircle className="w-7 h-7 text-primary" />
            </div>
            <h1 className="text-3xl font-semibold text-foreground tracking-tight mb-2">
              ¿Cómo usarás Solva?
            </h1>
            <p className="text-muted-foreground text-lg">
              Podrás cambiar esto más adelante
            </p>
          </div>

          <div className="flex-1 space-y-4">
            {/* Client Option */}
            <button
              onClick={() => setSelectedRole("client")}
              className={`w-full p-6 rounded-2xl border-2 text-left transition-all ${
                selectedRole === "client"
                  ? "border-primary bg-primary/5 shadow-md"
                  : "border-border/50 bg-card hover:border-border hover:bg-muted/30"
              }`}
            >
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  selectedRole === "client" ? "bg-primary" : "bg-muted"
                }`}>
                  <UserCircle className={`w-6 h-6 ${
                    selectedRole === "client" ? "text-primary-foreground" : "text-muted-foreground"
                  }`} />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground text-lg mb-1">
                    Busco servicios
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    Publica trabajos y contrata profesionales verificados para tus proyectos
                  </p>
                </div>
                {selectedRole === "client" && (
                  <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                    <Check className="w-4 h-4 text-primary-foreground" />
                  </div>
                )}
              </div>
              <div className="mt-4 pt-4 border-t border-border/50">
                <ul className="space-y-2">
                  {["Publica trabajos gratis", "Recibe ofertas de profesionales", "Pago seguro con escrow"].map((item) => (
                    <li key={item} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <ChevronRight className="w-4 h-4 text-primary" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </button>

            {/* Professional Option */}
            <button
              onClick={() => setSelectedRole("professional")}
              className={`w-full p-6 rounded-2xl border-2 text-left transition-all ${
                selectedRole === "professional"
                  ? "border-primary bg-primary/5 shadow-md"
                  : "border-border/50 bg-card hover:border-border hover:bg-muted/30"
              }`}
            >
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  selectedRole === "professional" ? "bg-primary" : "bg-muted"
                }`}>
                  <Briefcase className={`w-6 h-6 ${
                    selectedRole === "professional" ? "text-primary-foreground" : "text-muted-foreground"
                  }`} />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground text-lg mb-1">
                    Ofrezco servicios
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    Encuentra trabajos cerca de ti y genera ingresos con tus habilidades
                  </p>
                </div>
                {selectedRole === "professional" && (
                  <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                    <Check className="w-4 h-4 text-primary-foreground" />
                  </div>
                )}
              </div>
              <div className="mt-4 pt-4 border-t border-border/50">
                <ul className="space-y-2">
                  {["Accede a trabajos cercanos", "Cobra de forma segura", "Construye tu reputación"].map((item) => (
                    <li key={item} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <ChevronRight className="w-4 h-4 text-primary" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </button>
          </div>

          <div className="pt-6 flex gap-3">
            <Button
              variant="outline"
              onClick={() => setStep(1)}
              className="h-14 px-6 rounded-xl border-border/50"
            >
              Atrás
            </Button>
            <Button
              onClick={handleComplete}
              disabled={!selectedRole || isLoading}
              className="flex-1 h-14 rounded-xl text-base font-semibold shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 transition-all"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
              ) : (
                <>
                  Comenzar
                  <ArrowRight className="w-5 h-5 ml-2" />
                </>
              )}
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
