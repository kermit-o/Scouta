"use client"

import { Star, CheckCircle2, Shield, CreditCard, Settings, ChevronRight, LogOut, Bell, Scale, UserCog } from "lucide-react"
import type { User } from "@/lib/types"

interface ProfileScreenProps {
  user: User | null
  onNavigate: (screen: string) => void
  onLogout: () => void
}

export function ProfileScreen({ user, onNavigate, onLogout }: ProfileScreenProps) {
  const displayUser = user || {
    name: "Usuario Demo",
    email: "usuario@solva.com",
    avatar: "/placeholder.svg?height=80&width=80",
    rating: 4.9,
    jobsCompleted: 127,
    verified: false,
    kycStatus: "pending" as const,
    role: "client" as const,
    createdAt: "2023-01-15"
  }

  const memberSince = new Date(displayUser.createdAt || "2023-01-15").toLocaleDateString("es-ES", { 
    month: "short", 
    year: "numeric" 
  })

  const menuItems = [
    { 
      icon: Shield, 
      label: "Verificación KYC", 
      badge: displayUser.kycStatus === "verified" ? "Verificado" : "Pendiente",
      badgeColor: displayUser.kycStatus === "verified" ? "emerald" : "amber",
      action: () => onNavigate("kyc")
    },
    { 
      icon: Scale, 
      label: "Garantía Solva", 
      action: () => onNavigate("guarantee")
    },
    { 
      icon: CreditCard, 
      label: "Métodos de pago",
      action: () => {}
    },
    { 
      icon: Bell, 
      label: "Notificaciones",
      action: () => {}
    },
    { 
      icon: Settings, 
      label: "Configuración",
      action: () => {}
    },
  ]

  // Add admin option if user is admin
  if (displayUser.role === "admin" || true) { // Always show for demo
    menuItems.push({
      icon: UserCog,
      label: "Panel de Administración",
      badge: "Admin",
      badgeColor: "primary",
      action: () => onNavigate("admin")
    })
  }

  return (
    <div className="px-6 pt-14 pb-8">
      {/* Profile Card */}
      <div className="bg-card rounded-3xl p-6 border border-border/50 shadow-[0_4px_16px_rgba(0,0,0,0.06)] mb-6">
        <div className="flex items-center gap-4 mb-6">
          <div className="relative">
            <img
              src={displayUser.avatar || "/placeholder.svg?height=80&width=80"}
              alt={displayUser.name}
              className="w-20 h-20 rounded-2xl object-cover"
            />
            {displayUser.verified && (
              <div className="absolute -bottom-1 -right-1 w-7 h-7 bg-primary rounded-xl flex items-center justify-center ring-3 ring-card">
                <CheckCircle2 className="h-4 w-4 text-primary-foreground" />
              </div>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="text-xl font-bold text-foreground tracking-tight">{displayUser.name}</h1>
            <p className="text-sm text-muted-foreground mb-2">{displayUser.email}</p>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1">
                <Star className="h-4 w-4 text-amber-500 fill-amber-500" />
                <span className="text-sm font-semibold text-foreground">{displayUser.rating}</span>
              </div>
              <span className={`text-xs px-2 py-0.5 rounded-full ${
                displayUser.role === "professional" 
                  ? "bg-primary/10 text-primary" 
                  : "bg-muted text-muted-foreground"
              }`}>
                {displayUser.role === "professional" ? "Profesional" : "Cliente"}
              </span>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 bg-secondary/50 rounded-2xl text-center">
            <p className="text-2xl font-bold text-foreground">{displayUser.jobsCompleted}</p>
            <p className="text-xs text-muted-foreground mt-1">Trabajos completados</p>
          </div>
          <div className="p-4 bg-secondary/50 rounded-2xl text-center">
            <p className="text-2xl font-bold text-foreground">{memberSince}</p>
            <p className="text-xs text-muted-foreground mt-1">Miembro desde</p>
          </div>
        </div>
      </div>

      {/* Menu Items */}
      <div className="bg-card rounded-2xl border border-border/50 shadow-[0_2px_8px_rgba(0,0,0,0.04)] overflow-hidden mb-6">
        {menuItems.map((item, index) => {
          const Icon = item.icon
          return (
            <button
              key={item.label}
              onClick={item.action}
              className={`
                w-full flex items-center gap-4 px-5 py-4 text-left hover:bg-muted transition-colors
                ${index !== menuItems.length - 1 ? 'border-b border-border/50' : ''}
              `}
            >
              <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center">
                <Icon className="h-5 w-5 text-foreground" />
              </div>
              <span className="flex-1 text-sm font-medium text-foreground">{item.label}</span>
              {item.badge && (
                <span className={`
                  text-[10px] font-semibold uppercase tracking-wider px-2 py-1 rounded-md
                  ${item.badgeColor === 'emerald' 
                    ? 'text-emerald-600 bg-emerald-100 dark:text-emerald-400 dark:bg-emerald-950' 
                    : item.badgeColor === 'amber'
                    ? 'text-amber-600 bg-amber-100 dark:text-amber-400 dark:bg-amber-950'
                    : 'text-primary bg-primary/10'
                  }
                `}>
                  {item.badge}
                </span>
              )}
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </button>
          )
        })}
      </div>

      {/* Logout */}
      <button 
        onClick={onLogout}
        className="w-full flex items-center justify-center gap-2 p-4 text-destructive hover:bg-destructive/10 rounded-xl transition-colors"
      >
        <LogOut className="h-4 w-4" />
        <span className="text-sm font-medium">Cerrar sesión</span>
      </button>
    </div>
  )
}
