"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { 
  ArrowLeft, 
  Users,
  Briefcase,
  AlertTriangle,
  DollarSign,
  Search,
  CheckCircle2,
  XCircle,
  Clock,
  ChevronRight,
  Shield,
  TrendingUp,
  Eye
} from "lucide-react"

interface AdminScreenProps {
  onBack: () => void
}

type Tab = "overview" | "users" | "jobs" | "disputes" | "kyc"

const MOCK_STATS = {
  totalUsers: 12847,
  activeJobs: 342,
  pendingDisputes: 18,
  monthlyRevenue: 45230,
  newUsersToday: 156,
  completedJobsToday: 89,
}

const MOCK_PENDING_KYC = [
  { id: 1, name: "Maria Lopez", email: "maria@email.com", submitted: "Hace 2 horas", documents: 3 },
  { id: 2, name: "Juan Perez", email: "juan@email.com", submitted: "Hace 4 horas", documents: 3 },
  { id: 3, name: "Ana García", email: "ana@email.com", submitted: "Hace 6 horas", documents: 2 },
]

const MOCK_DISPUTES = [
  { id: 1, job: "Reparación de tubería", client: "Carlos M.", professional: "Pedro L.", amount: 150, status: "open", created: "Hace 1 día" },
  { id: 2, job: "Instalación eléctrica", client: "Laura S.", professional: "Miguel R.", amount: 280, status: "under-review", created: "Hace 2 días" },
  { id: 3, job: "Pintura de habitación", client: "Sofia T.", professional: "Roberto G.", amount: 200, status: "open", created: "Hace 3 días" },
]

const MOCK_RECENT_JOBS = [
  { id: 1, title: "Reparación de lavadora", client: "Ana M.", price: 120, status: "completed" },
  { id: 2, title: "Instalación de aire acondicionado", client: "Luis P.", price: 350, status: "in-progress" },
  { id: 3, title: "Limpieza profunda", client: "Carmen R.", price: 80, status: "open" },
]

export function AdminScreen({ onBack }: AdminScreenProps) {
  const [activeTab, setActiveTab] = useState<Tab>("overview")
  const [searchQuery, setSearchQuery] = useState("")

  const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
    { id: "overview", label: "Resumen", icon: TrendingUp },
    { id: "users", label: "Usuarios", icon: Users },
    { id: "jobs", label: "Trabajos", icon: Briefcase },
    { id: "disputes", label: "Disputas", icon: AlertTriangle },
    { id: "kyc", label: "KYC", icon: Shield },
  ]

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-xl border-b border-border/50">
        <div className="flex items-center gap-4 px-6 py-4">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-card border border-border/50 flex items-center justify-center shadow-sm"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-semibold text-foreground">Panel de Administración</h1>
            <p className="text-sm text-muted-foreground">Gestiona la plataforma</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 px-6 pb-3 overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                activeTab === tab.id
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted/50 text-muted-foreground hover:bg-muted"
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 px-6 py-6 space-y-6 overflow-y-auto pb-24">
        {activeTab === "overview" && (
          <>
            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Users className="w-5 h-5 text-primary" />
                  </div>
                </div>
                <p className="text-2xl font-bold text-foreground">{MOCK_STATS.totalUsers.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Usuarios totales</p>
                <p className="text-xs text-emerald-600 mt-1">+{MOCK_STATS.newUsersToday} hoy</p>
              </div>

              <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
                    <Briefcase className="w-5 h-5 text-emerald-600" />
                  </div>
                </div>
                <p className="text-2xl font-bold text-foreground">{MOCK_STATS.activeJobs}</p>
                <p className="text-sm text-muted-foreground">Trabajos activos</p>
                <p className="text-xs text-emerald-600 mt-1">{MOCK_STATS.completedJobsToday} completados hoy</p>
              </div>

              <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
                    <AlertTriangle className="w-5 h-5 text-amber-600" />
                  </div>
                </div>
                <p className="text-2xl font-bold text-foreground">{MOCK_STATS.pendingDisputes}</p>
                <p className="text-sm text-muted-foreground">Disputas pendientes</p>
                <p className="text-xs text-amber-600 mt-1">Requieren atención</p>
              </div>

              <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                    <DollarSign className="w-5 h-5 text-primary" />
                  </div>
                </div>
                <p className="text-2xl font-bold text-foreground">${MOCK_STATS.monthlyRevenue.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Ingresos del mes</p>
                <p className="text-xs text-emerald-600 mt-1">+12% vs mes anterior</p>
              </div>
            </div>

            {/* Recent Jobs */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-foreground">Trabajos recientes</h3>
                <button className="text-sm text-primary font-medium">Ver todos</button>
              </div>
              <div className="space-y-2">
                {MOCK_RECENT_JOBS.map((job) => (
                  <div key={job.id} className="flex items-center gap-3 p-3 bg-card rounded-xl border border-border/50">
                    <div className="flex-1">
                      <p className="font-medium text-foreground">{job.title}</p>
                      <p className="text-sm text-muted-foreground">{job.client}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-foreground">${job.price}</p>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        job.status === "completed" ? "bg-emerald-500/10 text-emerald-600" :
                        job.status === "in-progress" ? "bg-amber-500/10 text-amber-600" :
                        "bg-primary/10 text-primary"
                      }`}>
                        {job.status === "completed" ? "Completado" : job.status === "in-progress" ? "En progreso" : "Abierto"}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Pending KYC Preview */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-foreground">KYC pendientes</h3>
                <button 
                  onClick={() => setActiveTab("kyc")}
                  className="text-sm text-primary font-medium"
                >
                  Ver todos
                </button>
              </div>
              <div className="bg-amber-500/10 rounded-2xl p-4 border border-amber-500/20">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-amber-600" />
                  <div className="flex-1">
                    <p className="font-medium text-foreground">{MOCK_PENDING_KYC.length} verificaciones pendientes</p>
                    <p className="text-sm text-muted-foreground">Requieren revisión manual</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground" />
                </div>
              </div>
            </div>
          </>
        )}

        {activeTab === "users" && (
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Buscar usuarios..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 h-12 bg-card border-border/50 rounded-xl"
              />
            </div>

            <div className="space-y-2">
              {[
                { name: "Carlos Mendez", email: "carlos@email.com", role: "professional", verified: true, jobs: 127 },
                { name: "Ana García", email: "ana@email.com", role: "client", verified: true, jobs: 15 },
                { name: "Roberto Silva", email: "roberto@email.com", role: "professional", verified: false, jobs: 45 },
              ].map((user, i) => (
                <div key={i} className="flex items-center gap-3 p-4 bg-card rounded-xl border border-border/50">
                  <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center">
                    <span className="text-lg font-semibold text-muted-foreground">{user.name.charAt(0)}</span>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-foreground">{user.name}</p>
                      {user.verified && <CheckCircle2 className="w-4 h-4 text-primary" />}
                    </div>
                    <p className="text-sm text-muted-foreground">{user.email}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        user.role === "professional" ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"
                      }`}>
                        {user.role === "professional" ? "Profesional" : "Cliente"}
                      </span>
                      <span className="text-xs text-muted-foreground">{user.jobs} trabajos</span>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="rounded-lg">
                    <Eye className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "disputes" && (
          <div className="space-y-4">
            <div className="flex gap-2">
              <button className="px-4 py-2 rounded-full bg-primary text-primary-foreground text-sm font-medium">
                Abiertas ({MOCK_DISPUTES.filter(d => d.status === "open").length})
              </button>
              <button className="px-4 py-2 rounded-full bg-muted text-muted-foreground text-sm font-medium">
                En revisión ({MOCK_DISPUTES.filter(d => d.status === "under-review").length})
              </button>
            </div>

            <div className="space-y-3">
              {MOCK_DISPUTES.map((dispute) => (
                <div key={dispute.id} className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="font-semibold text-foreground">{dispute.job}</p>
                      <p className="text-sm text-muted-foreground">{dispute.created}</p>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      dispute.status === "open" ? "bg-amber-500/10 text-amber-600" : "bg-primary/10 text-primary"
                    }`}>
                      {dispute.status === "open" ? "Abierta" : "En revisión"}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                    <span>Cliente: {dispute.client}</span>
                    <span>Prof: {dispute.professional}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <p className="font-semibold text-foreground">${dispute.amount}</p>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" className="rounded-lg">
                        Ver detalles
                      </Button>
                      <Button size="sm" className="rounded-lg">
                        Resolver
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "kyc" && (
          <div className="space-y-4">
            <div className="flex gap-2">
              <button className="px-4 py-2 rounded-full bg-primary text-primary-foreground text-sm font-medium">
                Pendientes ({MOCK_PENDING_KYC.length})
              </button>
              <button className="px-4 py-2 rounded-full bg-muted text-muted-foreground text-sm font-medium">
                Verificados
              </button>
              <button className="px-4 py-2 rounded-full bg-muted text-muted-foreground text-sm font-medium">
                Rechazados
              </button>
            </div>

            <div className="space-y-3">
              {MOCK_PENDING_KYC.map((kyc) => (
                <div key={kyc.id} className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center">
                      <span className="text-lg font-semibold text-muted-foreground">{kyc.name.charAt(0)}</span>
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-foreground">{kyc.name}</p>
                      <p className="text-sm text-muted-foreground">{kyc.email}</p>
                      <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                        <span>{kyc.documents} documentos</span>
                        <span>{kyc.submitted}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <Button variant="outline" size="sm" className="flex-1 rounded-lg">
                      <Eye className="w-4 h-4 mr-1" />
                      Revisar
                    </Button>
                    <Button size="sm" className="rounded-lg bg-emerald-600 hover:bg-emerald-700">
                      <CheckCircle2 className="w-4 h-4 mr-1" />
                      Aprobar
                    </Button>
                    <Button size="sm" variant="destructive" className="rounded-lg">
                      <XCircle className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "jobs" && (
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Buscar trabajos..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 h-12 bg-card border-border/50 rounded-xl"
              />
            </div>

            <div className="flex gap-2 overflow-x-auto pb-2">
              <button className="px-4 py-2 rounded-full bg-primary text-primary-foreground text-sm font-medium whitespace-nowrap">
                Todos
              </button>
              <button className="px-4 py-2 rounded-full bg-muted text-muted-foreground text-sm font-medium whitespace-nowrap">
                Abiertos
              </button>
              <button className="px-4 py-2 rounded-full bg-muted text-muted-foreground text-sm font-medium whitespace-nowrap">
                En progreso
              </button>
              <button className="px-4 py-2 rounded-full bg-muted text-muted-foreground text-sm font-medium whitespace-nowrap">
                Completados
              </button>
            </div>

            <div className="space-y-2">
              {MOCK_RECENT_JOBS.map((job) => (
                <div key={job.id} className="flex items-center gap-3 p-4 bg-card rounded-xl border border-border/50">
                  <div className="flex-1">
                    <p className="font-medium text-foreground">{job.title}</p>
                    <p className="text-sm text-muted-foreground">{job.client}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-foreground">${job.price}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      job.status === "completed" ? "bg-emerald-500/10 text-emerald-600" :
                      job.status === "in-progress" ? "bg-amber-500/10 text-amber-600" :
                      "bg-primary/10 text-primary"
                    }`}>
                      {job.status === "completed" ? "Completado" : job.status === "in-progress" ? "En progreso" : "Abierto"}
                    </span>
                  </div>
                  <Button variant="outline" size="sm" className="rounded-lg">
                    <Eye className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
