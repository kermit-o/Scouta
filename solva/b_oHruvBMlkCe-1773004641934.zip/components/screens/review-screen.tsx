"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { 
  ArrowLeft, 
  Star,
  Camera,
  X,
  CheckCircle2,
  Sparkles
} from "lucide-react"
import type { Contract } from "@/lib/types"

interface ReviewScreenProps {
  contract: Contract | null
  onBack: () => void
  onSubmit: () => void
}

export function ReviewScreen({ contract, onBack, onSubmit }: ReviewScreenProps) {
  const [rating, setRating] = useState(0)
  const [hoveredRating, setHoveredRating] = useState(0)
  const [comment, setComment] = useState("")
  const [photos, setPhotos] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const ratingLabels = ["", "Malo", "Regular", "Bueno", "Muy bueno", "Excelente"]

  const handleAddPhoto = () => {
    setPhotos([...photos, `/placeholder.svg?height=200&width=200&text=Foto${photos.length + 1}`])
  }

  const handleRemovePhoto = (index: number) => {
    setPhotos(photos.filter((_, i) => i !== index))
  }

  const handleSubmit = async () => {
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsLoading(false)
    setIsSubmitted(true)
  }

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <div className="flex-1 flex flex-col items-center justify-center px-8">
          <div className="w-20 h-20 rounded-full bg-emerald-500/20 flex items-center justify-center mb-6">
            <CheckCircle2 className="w-10 h-10 text-emerald-600" />
          </div>
          <h1 className="text-2xl font-semibold text-foreground text-center mb-2">
            ¡Gracias por tu reseña!
          </h1>
          <p className="text-muted-foreground text-center mb-8">
            Tu opinión ayuda a otros usuarios a tomar mejores decisiones
          </p>
          <Button
            onClick={onSubmit}
            className="w-full max-w-xs h-14 rounded-xl text-base font-semibold shadow-lg shadow-primary/20"
          >
            Volver al inicio
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-xl border-b border-border/50">
        <div className="flex items-center gap-4 px-6 py-4">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-card border border-border/50 flex items-center justify-center shadow-sm"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
          <h1 className="text-lg font-semibold text-foreground">Dejar reseña</h1>
        </div>
      </div>

      <div className="flex-1 px-6 py-6 space-y-6">
        {/* Professional Card */}
        <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
          <div className="flex items-center gap-4">
            <img
              src="/placeholder.svg?height=64&width=64"
              alt="Professional"
              className="w-14 h-14 rounded-xl object-cover"
            />
            <div>
              <h3 className="font-semibold text-foreground">Carlos Mendez</h3>
              <p className="text-sm text-muted-foreground">Reparación de tubería</p>
            </div>
          </div>
        </div>

        {/* Rating */}
        <div className="space-y-4">
          <h4 className="font-semibold text-foreground text-center">
            ¿Cómo calificarías el servicio?
          </h4>
          <div className="flex justify-center gap-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                onClick={() => setRating(star)}
                onMouseEnter={() => setHoveredRating(star)}
                onMouseLeave={() => setHoveredRating(0)}
                className="p-1 transition-transform hover:scale-110"
              >
                <Star
                  className={`w-10 h-10 transition-colors ${
                    star <= (hoveredRating || rating)
                      ? "text-amber-500 fill-amber-500"
                      : "text-muted-foreground/30"
                  }`}
                />
              </button>
            ))}
          </div>
          {(hoveredRating || rating) > 0 && (
            <p className="text-center text-muted-foreground">
              {ratingLabels[hoveredRating || rating]}
            </p>
          )}
        </div>

        {/* Comment */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">
            Comparte tu experiencia
          </label>
          <Textarea
            placeholder="¿Qué te pareció el servicio? ¿Cumplió con tus expectativas?"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            className="min-h-32 bg-card border-border/50 rounded-xl text-base shadow-sm resize-none"
          />
        </div>

        {/* Photos */}
        <div className="space-y-3">
          <label className="text-sm font-medium text-foreground">
            Agregar fotos del trabajo (opcional)
          </label>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {photos.map((photo, index) => (
              <div key={index} className="relative flex-shrink-0">
                <img
                  src={photo}
                  alt={`Foto ${index + 1}`}
                  className="w-20 h-20 rounded-xl object-cover"
                />
                <button
                  onClick={() => handleRemovePhoto(index)}
                  className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
            {photos.length < 5 && (
              <button
                onClick={handleAddPhoto}
                className="w-20 h-20 rounded-xl border-2 border-dashed border-border flex flex-col items-center justify-center gap-1 hover:border-primary hover:bg-primary/5 transition-colors flex-shrink-0"
              >
                <Camera className="w-5 h-5 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Añadir</span>
              </button>
            )}
          </div>
          <p className="text-xs text-muted-foreground">
            Las fotos ayudan a otros usuarios a ver la calidad del trabajo
          </p>
        </div>

        {/* Tips */}
        <div className="bg-primary/5 rounded-2xl p-4 border border-primary/20">
          <div className="flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-foreground text-sm mb-1">Consejos para una buena reseña</p>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>- Describe la calidad del trabajo realizado</li>
                <li>- Menciona la puntualidad y profesionalismo</li>
                <li>- Comparte si lo recomendarías</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="sticky bottom-0 bg-background/80 backdrop-blur-xl border-t border-border/50 px-6 py-4">
        <Button
          onClick={handleSubmit}
          disabled={rating === 0 || !comment || isLoading}
          className="w-full h-14 rounded-xl text-base font-semibold shadow-lg shadow-primary/20"
        >
          {isLoading ? (
            <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
          ) : (
            "Publicar reseña"
          )}
        </Button>
      </div>
    </div>
  )
}
