"use client"

import { Button } from "@/components/ui/button"
import { 
  ArrowLeft, 
  Shield,
  CheckCircle2,
  Clock,
  CreditCard,
  MessageCircle,
  Scale,
  Sparkles
} from "lucide-react"

interface GuaranteeScreenProps {
  onBack: () => void
}

const GUARANTEES = [
  {
    icon: CreditCard,
    title: "Pago protegido",
    description: "Tu dinero se mantiene seguro en escrow hasta que confirmes que el trabajo está completo.",
  },
  {
    icon: Clock,
    title: "Garantía de 7 días",
    description: "Si algo sale mal dentro de los 7 días posteriores al trabajo, te ayudamos a resolverlo.",
  },
  {
    icon: Scale,
    title: "Mediación justa",
    description: "Nuestro equipo interviene imparcialmente en caso de disputas para encontrar una solución justa.",
  },
  {
    icon: MessageCircle,
    title: "Soporte 24/7",
    description: "Nuestro equipo de atención está disponible las 24 horas para ayudarte con cualquier problema.",
  },
]

const COVERAGE = [
  "Trabajos incompletos",
  "Calidad insatisfactoria",
  "Profesional no se presenta",
  "Daños causados durante el trabajo",
  "Cobros indebidos",
  "Fraude o estafa",
]

const NOT_COVERED = [
  "Cambios de opinión después de completar el trabajo",
  "Disputas por preferencias personales",
  "Trabajos acordados fuera de Solva",
  "Daños preexistentes no documentados",
]

export function GuaranteeScreen({ onBack }: GuaranteeScreenProps) {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-xl border-b border-border/50">
        <div className="flex items-center gap-4 px-6 py-4">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-card border border-border/50 flex items-center justify-center shadow-sm"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
          <h1 className="text-lg font-semibold text-foreground">Garantía Solva</h1>
        </div>
      </div>

      <div className="flex-1 px-6 py-6 space-y-8 overflow-y-auto pb-24">
        {/* Hero */}
        <div className="text-center py-4">
          <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
            <Shield className="w-10 h-10 text-primary" />
          </div>
          <h2 className="text-2xl font-semibold text-foreground mb-2">
            Tu tranquilidad es nuestra prioridad
          </h2>
          <p className="text-muted-foreground">
            Cada transacción en Solva está protegida por nuestra garantía integral
          </p>
        </div>

        {/* Guarantees */}
        <div className="space-y-4">
          <h3 className="font-semibold text-foreground">¿Qué incluye?</h3>
          <div className="grid gap-4">
            {GUARANTEES.map((guarantee, i) => (
              <div 
                key={i}
                className="flex items-start gap-4 p-4 bg-card rounded-2xl border border-border/50 shadow-sm"
              >
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <guarantee.icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-medium text-foreground mb-1">{guarantee.title}</h4>
                  <p className="text-sm text-muted-foreground">{guarantee.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* What's Covered */}
        <div className="space-y-4">
          <h3 className="font-semibold text-foreground">Qué está cubierto</h3>
          <div className="bg-emerald-500/5 rounded-2xl p-5 border border-emerald-500/20">
            <div className="space-y-3">
              {COVERAGE.map((item, i) => (
                <div key={i} className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                  <span className="text-sm text-foreground">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* What's Not Covered */}
        <div className="space-y-4">
          <h3 className="font-semibold text-foreground">Qué no está cubierto</h3>
          <div className="bg-muted/50 rounded-2xl p-5">
            <div className="space-y-3">
              {NOT_COVERED.map((item, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full border-2 border-muted-foreground/30 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-muted-foreground">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* How to Use */}
        <div className="space-y-4">
          <h3 className="font-semibold text-foreground">¿Cómo usar la garantía?</h3>
          <div className="space-y-3">
            {[
              { step: 1, title: "Reporta el problema", description: "Abre una disputa desde el contrato activo" },
              { step: 2, title: "Proporciona evidencia", description: "Sube fotos y describe la situación" },
              { step: 3, title: "Espera la revisión", description: "Nuestro equipo evaluará el caso en 24-48h" },
              { step: 4, title: "Recibe la resolución", description: "Te notificaremos la decisión y los siguientes pasos" },
            ].map((item) => (
              <div key={item.step} className="flex items-start gap-4 p-4 bg-card rounded-xl border border-border/50">
                <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                  <span className="text-sm font-bold text-primary-foreground">{item.step}</span>
                </div>
                <div>
                  <h4 className="font-medium text-foreground">{item.title}</h4>
                  <p className="text-sm text-muted-foreground">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Pro Tip */}
        <div className="bg-primary/5 rounded-2xl p-5 border border-primary/20">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-1">Consejo Pro</h4>
              <p className="text-sm text-muted-foreground">
                Siempre documenta el estado inicial del trabajo con fotos. Esto te ayudará en caso de necesitar abrir una disputa.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="sticky bottom-0 bg-background/80 backdrop-blur-xl border-t border-border/50 px-6 py-4">
        <Button
          onClick={onBack}
          className="w-full h-14 rounded-xl text-base font-semibold shadow-lg shadow-primary/20"
        >
          Entendido
        </Button>
      </div>
    </div>
  )
}
