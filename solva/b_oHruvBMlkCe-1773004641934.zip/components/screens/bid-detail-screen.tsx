"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { 
  ArrowLeft, 
  Star, 
  Clock, 
  CheckCircle2,
  MessageCircle,
  DollarSign,
  Shield,
  ChevronRight
} from "lucide-react"
import type { Job, Bid, Contract } from "@/lib/types"

interface BidDetailScreenProps {
  job: Job | null
  onBack: () => void
  onAcceptBid: (contract: Contract) => void
}

// Mock bids for demo
const MOCK_BIDS: Bid[] = [
  {
    id: "bid-1",
    jobId: "job-1",
    professional: {
      id: "pro-1",
      name: "Carlos Mendez",
      avatar: "/placeholder.svg?height=80&width=80",
      profession: "Plomero certificado",
      rating: 4.9,
      jobsCompleted: 127,
      hourlyRate: 35,
      verified: true,
    },
    amount: 150,
    message: "Hola! Tengo experiencia en este tipo de trabajos. Puedo ir mañana por la mañana y traigo todas las herramientas necesarias. El precio incluye materiales básicos.",
    estimatedDuration: "2-3 horas",
    createdAt: "Hace 15 min",
    status: "pending",
  },
  {
    id: "bid-2",
    jobId: "job-1",
    professional: {
      id: "pro-2",
      name: "Ana García",
      avatar: "/placeholder.svg?height=80&width=80",
      profession: "Técnico multiservicios",
      rating: 4.7,
      jobsCompleted: 89,
      hourlyRate: 30,
      verified: true,
    },
    amount: 180,
    message: "Buenos días. Puedo realizar el trabajo esta semana. Tengo garantía de 30 días en todos mis trabajos.",
    estimatedDuration: "3-4 horas",
    createdAt: "Hace 1 hora",
    status: "pending",
  },
  {
    id: "bid-3",
    jobId: "job-1",
    professional: {
      id: "pro-3",
      name: "Roberto Silva",
      avatar: "/placeholder.svg?height=80&width=80",
      profession: "Plomero",
      rating: 4.5,
      jobsCompleted: 45,
      hourlyRate: 25,
      verified: false,
    },
    amount: 120,
    message: "Puedo hacerlo a buen precio. Disponibilidad inmediata.",
    estimatedDuration: "2 horas",
    createdAt: "Hace 2 horas",
    status: "pending",
  },
]

export function BidDetailScreen({ job, onBack, onAcceptBid }: BidDetailScreenProps) {
  const [selectedBid, setSelectedBid] = useState<Bid | null>(null)
  const [showMakeBid, setShowMakeBid] = useState(false)
  const [bidAmount, setBidAmount] = useState("")
  const [bidMessage, setBidMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleAcceptBid = async (bid: Bid) => {
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsLoading(false)
    
    const contract: Contract = {
      id: `contract-${Date.now()}`,
      jobId: bid.jobId,
      clientId: "user-1",
      professionalId: bid.professional.id,
      agreedAmount: bid.amount,
      escrowStatus: "pending",
      startDate: new Date().toISOString(),
      expectedEndDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      status: "active",
    }
    
    onAcceptBid(contract)
  }

  const handleSubmitBid = async () => {
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsLoading(false)
    setShowMakeBid(false)
    onBack()
  }

  if (showMakeBid) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-xl border-b border-border/50">
          <div className="flex items-center gap-4 px-6 py-4">
            <button
              onClick={() => setShowMakeBid(false)}
              className="w-10 h-10 rounded-full bg-card border border-border/50 flex items-center justify-center shadow-sm"
            >
              <ArrowLeft className="w-5 h-5 text-foreground" />
            </button>
            <h1 className="text-lg font-semibold text-foreground">Hacer oferta</h1>
          </div>
        </div>

        <div className="flex-1 px-6 py-6 space-y-6">
          <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
            <h3 className="font-semibold text-foreground mb-2">{job?.title}</h3>
            <p className="text-sm text-muted-foreground">Presupuesto: ${job?.price}</p>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Tu oferta</label>
            <div className="relative">
              <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                type="number"
                placeholder="0.00"
                value={bidAmount}
                onChange={(e) => setBidAmount(e.target.value)}
                className="pl-12 h-14 bg-card border-border/50 rounded-xl text-base shadow-sm"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Mensaje al cliente</label>
            <Textarea
              placeholder="Describe tu experiencia, disponibilidad y cualquier detalle relevante..."
              value={bidMessage}
              onChange={(e) => setBidMessage(e.target.value)}
              className="min-h-32 bg-card border-border/50 rounded-xl text-base shadow-sm resize-none"
            />
          </div>

          <div className="bg-primary/5 rounded-2xl p-4 border border-primary/20">
            <div className="flex items-start gap-3">
              <Shield className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-foreground text-sm mb-1">Pago protegido</p>
                <p className="text-xs text-muted-foreground">
                  El cliente depositará el pago en escrow antes de que comiences el trabajo.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="sticky bottom-0 bg-background/80 backdrop-blur-xl border-t border-border/50 px-6 py-4">
          <Button
            onClick={handleSubmitBid}
            disabled={!bidAmount || !bidMessage || isLoading}
            className="w-full h-14 rounded-xl text-base font-semibold shadow-lg shadow-primary/20"
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
            ) : (
              "Enviar oferta"
            )}
          </Button>
        </div>
      </div>
    )
  }

  if (selectedBid) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-xl border-b border-border/50">
          <div className="flex items-center gap-4 px-6 py-4">
            <button
              onClick={() => setSelectedBid(null)}
              className="w-10 h-10 rounded-full bg-card border border-border/50 flex items-center justify-center shadow-sm"
            >
              <ArrowLeft className="w-5 h-5 text-foreground" />
            </button>
            <h1 className="text-lg font-semibold text-foreground">Detalle de oferta</h1>
          </div>
        </div>

        <div className="flex-1 px-6 py-6 space-y-6">
          {/* Professional Info */}
          <div className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm">
            <div className="flex items-start gap-4 mb-4">
              <img
                src={selectedBid.professional.avatar}
                alt={selectedBid.professional.name}
                className="w-16 h-16 rounded-2xl object-cover"
              />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold text-foreground">{selectedBid.professional.name}</h3>
                  {selectedBid.professional.verified && (
                    <CheckCircle2 className="w-4 h-4 text-primary" />
                  )}
                </div>
                <p className="text-sm text-muted-foreground mb-2">{selectedBid.professional.profession}</p>
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                    <span className="text-sm font-medium text-foreground">{selectedBid.professional.rating}</span>
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {selectedBid.professional.jobsCompleted} trabajos
                  </span>
                </div>
              </div>
            </div>

            <Button variant="outline" className="w-full h-12 rounded-xl border-border/50">
              <MessageCircle className="w-4 h-4 mr-2" />
              Enviar mensaje
            </Button>
          </div>

          {/* Bid Details */}
          <div className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm space-y-4">
            <h4 className="font-semibold text-foreground">Detalles de la oferta</h4>
            
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Precio ofertado</span>
              <span className="text-2xl font-bold text-foreground">${selectedBid.amount}</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Tiempo estimado</span>
              <div className="flex items-center gap-1 text-foreground">
                <Clock className="w-4 h-4" />
                <span>{selectedBid.estimatedDuration}</span>
              </div>
            </div>

            <div className="h-px bg-border" />

            <div>
              <p className="text-sm text-muted-foreground mb-2">Mensaje del profesional</p>
              <p className="text-foreground">{selectedBid.message}</p>
            </div>
          </div>

          {/* Escrow Info */}
          <div className="bg-primary/5 rounded-2xl p-4 border border-primary/20">
            <div className="flex items-start gap-3">
              <Shield className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-foreground text-sm mb-1">Pago seguro con escrow</p>
                <p className="text-xs text-muted-foreground">
                  Al aceptar, depositarás ${selectedBid.amount} en escrow. El pago solo se libera cuando confirmas que el trabajo está completo.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="sticky bottom-0 bg-background/80 backdrop-blur-xl border-t border-border/50 px-6 py-4 space-y-3">
          <Button
            onClick={() => handleAcceptBid(selectedBid)}
            disabled={isLoading}
            className="w-full h-14 rounded-xl text-base font-semibold shadow-lg shadow-primary/20"
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
            ) : (
              <>
                Aceptar oferta y pagar
                <ChevronRight className="w-5 h-5 ml-2" />
              </>
            )}
          </Button>
          <Button
            variant="outline"
            onClick={() => setSelectedBid(null)}
            className="w-full h-12 rounded-xl border-border/50"
          >
            Ver otras ofertas
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-xl border-b border-border/50">
        <div className="flex items-center gap-4 px-6 py-4">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-card border border-border/50 flex items-center justify-center shadow-sm"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-semibold text-foreground">Ofertas recibidas</h1>
            <p className="text-sm text-muted-foreground">{MOCK_BIDS.length} ofertas</p>
          </div>
        </div>
      </div>

      <div className="flex-1 px-6 py-6 space-y-4">
        {/* Job Summary */}
        <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
          <h3 className="font-semibold text-foreground mb-1">{job?.title || "Reparación de tubería"}</h3>
          <p className="text-sm text-muted-foreground">Presupuesto: ${job?.price || 200}</p>
        </div>

        {/* Bids List */}
        <div className="space-y-3">
          {MOCK_BIDS.map((bid) => (
            <button
              key={bid.id}
              onClick={() => setSelectedBid(bid)}
              className="w-full bg-card rounded-2xl border border-border/50 p-4 shadow-sm text-left hover:shadow-md transition-shadow"
            >
              <div className="flex items-start gap-3">
                <img
                  src={bid.professional.avatar}
                  alt={bid.professional.name}
                  className="w-12 h-12 rounded-xl object-cover"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-semibold text-foreground truncate">{bid.professional.name}</h4>
                    {bid.professional.verified && (
                      <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0" />
                    )}
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                    <span className="text-sm text-foreground">{bid.professional.rating}</span>
                    <span className="text-sm text-muted-foreground">·</span>
                    <span className="text-sm text-muted-foreground">{bid.professional.jobsCompleted} trabajos</span>
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-2">{bid.message}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-xl font-bold text-foreground">${bid.amount}</p>
                  <p className="text-xs text-muted-foreground">{bid.createdAt}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Make Bid Button (for professionals) */}
      <div className="sticky bottom-0 bg-background/80 backdrop-blur-xl border-t border-border/50 px-6 py-4">
        <Button
          onClick={() => setShowMakeBid(true)}
          className="w-full h-14 rounded-xl text-base font-semibold shadow-lg shadow-primary/20"
        >
          Hacer una oferta
        </Button>
      </div>
    </div>
  )
}
