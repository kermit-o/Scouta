"use client"

import { Search } from "lucide-react"
import { messages } from "@/lib/mock-data"

export function MessagesScreen() {
  return (
    <div className="px-6 pt-14">
      {/* Header */}
      <header className="mb-6">
        <h1 className="text-2xl font-semibold text-foreground tracking-tight">Messages</h1>
        <p className="text-sm text-muted-foreground mt-1">Your conversations</p>
      </header>

      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <input
          type="text"
          placeholder="Search messages..."
          className="w-full h-11 pl-11 pr-4 bg-card rounded-xl border border-border/50 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary/50 transition-all shadow-[0_2px_8px_rgba(0,0,0,0.04)]"
        />
      </div>

      {/* Messages List */}
      <div className="space-y-2">
        {messages.map((message) => (
          <button
            key={message.id}
            className="w-full p-4 bg-card rounded-2xl border border-border/50 text-left shadow-[0_2px_8px_rgba(0,0,0,0.04)] transition-all duration-300 hover:shadow-[0_8px_24px_rgba(0,0,0,0.08)] hover:border-border active:scale-[0.99]"
          >
            <div className="flex items-center gap-3">
              <div className="relative">
                <img
                  src={message.avatar}
                  alt={message.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                {message.unread > 0 && (
                  <div className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-primary rounded-full flex items-center justify-center ring-2 ring-card">
                    <span className="text-[10px] font-bold text-primary-foreground">{message.unread}</span>
                  </div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <h3 className="font-semibold text-foreground text-sm">{message.name}</h3>
                  <span className="text-[10px] text-muted-foreground">{message.timestamp}</span>
                </div>
                <p className={`text-sm truncate ${message.unread > 0 ? 'text-foreground font-medium' : 'text-muted-foreground'}`}>
                  {message.lastMessage}
                </p>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}
