"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { 
  ArrowLeft, 
  Shield, 
  CheckCircle2,
  Clock,
  AlertTriangle,
  CreditCard,
  Building2,
  ChevronRight,
  Lock,
  Wallet
} from "lucide-react"
import type { Contract } from "@/lib/types"

interface ContractScreenProps {
  contract: Contract | null
  onBack: () => void
  onComplete: () => void
  onDispute: () => void
}

type PaymentMethod = "card" | "bank" | "wallet"

export function ContractScreen({ contract, onBack, onComplete, onDispute }: ContractScreenProps) {
  const [step, setStep] = useState<"contract" | "payment" | "confirm" | "active">("contract")
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [escrowFunded, setEscrowFunded] = useState(false)

  const amount = contract?.agreedAmount || 150
  const serviceFee = amount * 0.05
  const total = amount + serviceFee

  const handleFundEscrow = async () => {
    if (!paymentMethod) return
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setIsLoading(false)
    setEscrowFunded(true)
    setStep("active")
  }

  const handleReleasePayment = async () => {
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsLoading(false)
    onComplete()
  }

  if (step === "active") {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-xl border-b border-border/50">
          <div className="flex items-center gap-4 px-6 py-4">
            <button
              onClick={onBack}
              className="w-10 h-10 rounded-full bg-card border border-border/50 flex items-center justify-center shadow-sm"
            >
              <ArrowLeft className="w-5 h-5 text-foreground" />
            </button>
            <h1 className="text-lg font-semibold text-foreground">Contrato activo</h1>
          </div>
        </div>

        <div className="flex-1 px-6 py-6 space-y-6">
          {/* Escrow Status */}
          <div className="bg-emerald-500/10 rounded-2xl p-6 border border-emerald-500/20">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-emerald-500/20 flex items-center justify-center">
                <Shield className="w-6 h-6 text-emerald-600" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Pago en escrow</h3>
                <p className="text-sm text-muted-foreground">Fondos protegidos</p>
              </div>
            </div>
            <div className="bg-card rounded-xl p-4 border border-border/50">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Monto depositado</span>
                <span className="text-2xl font-bold text-foreground">${amount}</span>
              </div>
            </div>
          </div>

          {/* Contract Details */}
          <div className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm space-y-4">
            <h4 className="font-semibold text-foreground">Detalles del contrato</h4>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Estado</span>
                <span className="flex items-center gap-1.5 text-emerald-600 font-medium">
                  <Clock className="w-4 h-4" />
                  En progreso
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Profesional</span>
                <span className="text-foreground">Carlos Mendez</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Fecha inicio</span>
                <span className="text-foreground">{new Date().toLocaleDateString()}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Fecha esperada</span>
                <span className="text-foreground">{new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toLocaleDateString()}</span>
              </div>
            </div>
          </div>

          {/* Actions Info */}
          <div className="space-y-3">
            <h4 className="text-sm font-medium text-foreground">Cuando el trabajo esté completo:</h4>
            <div className="space-y-2">
              {[
                "Revisa que el trabajo cumpla con lo acordado",
                "Libera el pago al profesional",
                "Deja una reseña de tu experiencia",
              ].map((tip, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-medium text-muted-foreground">{i + 1}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{tip}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Dispute Option */}
          <button
            onClick={onDispute}
            className="w-full flex items-center gap-3 p-4 rounded-xl bg-amber-500/10 border border-amber-500/20"
          >
            <AlertTriangle className="w-5 h-5 text-amber-600" />
            <div className="flex-1 text-left">
              <p className="font-medium text-foreground text-sm">¿Problemas con el trabajo?</p>
              <p className="text-xs text-muted-foreground">Abre una disputa para resolverlo</p>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>

        <div className="sticky bottom-0 bg-background/80 backdrop-blur-xl border-t border-border/50 px-6 py-4 space-y-3">
          <Button
            onClick={handleReleasePayment}
            disabled={isLoading}
            className="w-full h-14 rounded-xl text-base font-semibold shadow-lg shadow-primary/20"
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
            ) : (
              <>
                <CheckCircle2 className="w-5 h-5 mr-2" />
                Trabajo completado - Liberar pago
              </>
            )}
          </Button>
        </div>
      </div>
    )
  }

  if (step === "payment") {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-xl border-b border-border/50">
          <div className="flex items-center gap-4 px-6 py-4">
            <button
              onClick={() => setStep("contract")}
              className="w-10 h-10 rounded-full bg-card border border-border/50 flex items-center justify-center shadow-sm"
            >
              <ArrowLeft className="w-5 h-5 text-foreground" />
            </button>
            <h1 className="text-lg font-semibold text-foreground">Método de pago</h1>
          </div>
        </div>

        <div className="flex-1 px-6 py-6 space-y-6">
          {/* Payment Methods */}
          <div className="space-y-3">
            <button
              onClick={() => setPaymentMethod("card")}
              className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 transition-all ${
                paymentMethod === "card"
                  ? "border-primary bg-primary/5 shadow-sm"
                  : "border-border/50 bg-card hover:border-border"
              }`}
            >
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                paymentMethod === "card" ? "bg-primary" : "bg-muted"
              }`}>
                <CreditCard className={`w-6 h-6 ${
                  paymentMethod === "card" ? "text-primary-foreground" : "text-muted-foreground"
                }`} />
              </div>
              <div className="flex-1 text-left">
                <p className="font-medium text-foreground">Tarjeta de crédito/débito</p>
                <p className="text-sm text-muted-foreground">Visa, Mastercard, AMEX</p>
              </div>
              {paymentMethod === "card" && (
                <CheckCircle2 className="w-5 h-5 text-primary" />
              )}
            </button>

            <button
              onClick={() => setPaymentMethod("bank")}
              className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 transition-all ${
                paymentMethod === "bank"
                  ? "border-primary bg-primary/5 shadow-sm"
                  : "border-border/50 bg-card hover:border-border"
              }`}
            >
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                paymentMethod === "bank" ? "bg-primary" : "bg-muted"
              }`}>
                <Building2 className={`w-6 h-6 ${
                  paymentMethod === "bank" ? "text-primary-foreground" : "text-muted-foreground"
                }`} />
              </div>
              <div className="flex-1 text-left">
                <p className="font-medium text-foreground">Transferencia bancaria</p>
                <p className="text-sm text-muted-foreground">SPEI / Transferencia directa</p>
              </div>
              {paymentMethod === "bank" && (
                <CheckCircle2 className="w-5 h-5 text-primary" />
              )}
            </button>

            <button
              onClick={() => setPaymentMethod("wallet")}
              className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 transition-all ${
                paymentMethod === "wallet"
                  ? "border-primary bg-primary/5 shadow-sm"
                  : "border-border/50 bg-card hover:border-border"
              }`}
            >
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                paymentMethod === "wallet" ? "bg-primary" : "bg-muted"
              }`}>
                <Wallet className={`w-6 h-6 ${
                  paymentMethod === "wallet" ? "text-primary-foreground" : "text-muted-foreground"
                }`} />
              </div>
              <div className="flex-1 text-left">
                <p className="font-medium text-foreground">Saldo Solva</p>
                <p className="text-sm text-muted-foreground">$0.00 disponible</p>
              </div>
              {paymentMethod === "wallet" && (
                <CheckCircle2 className="w-5 h-5 text-primary" />
              )}
            </button>
          </div>

          {/* Summary */}
          <div className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm space-y-3">
            <h4 className="font-semibold text-foreground">Resumen del pago</h4>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Servicio</span>
                <span className="text-foreground">${amount.toFixed(2)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Tarifa de servicio (5%)</span>
                <span className="text-foreground">${serviceFee.toFixed(2)}</span>
              </div>
              <div className="h-px bg-border" />
              <div className="flex items-center justify-between">
                <span className="font-semibold text-foreground">Total</span>
                <span className="text-xl font-bold text-foreground">${total.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Security Info */}
          <div className="flex items-center gap-3 text-sm text-muted-foreground">
            <Lock className="w-4 h-4" />
            <span>Pago seguro con encriptación SSL</span>
          </div>
        </div>

        <div className="sticky bottom-0 bg-background/80 backdrop-blur-xl border-t border-border/50 px-6 py-4">
          <Button
            onClick={handleFundEscrow}
            disabled={!paymentMethod || isLoading}
            className="w-full h-14 rounded-xl text-base font-semibold shadow-lg shadow-primary/20"
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
            ) : (
              <>
                Depositar ${total.toFixed(2)} en escrow
                <ChevronRight className="w-5 h-5 ml-2" />
              </>
            )}
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-xl border-b border-border/50">
        <div className="flex items-center gap-4 px-6 py-4">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-card border border-border/50 flex items-center justify-center shadow-sm"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
          <h1 className="text-lg font-semibold text-foreground">Contrato</h1>
        </div>
      </div>

      <div className="flex-1 px-6 py-6 space-y-6">
        {/* Success Message */}
        <div className="bg-emerald-500/10 rounded-2xl p-6 border border-emerald-500/20 text-center">
          <div className="w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="w-8 h-8 text-emerald-600" />
          </div>
          <h3 className="font-semibold text-foreground text-lg mb-2">Oferta aceptada</h3>
          <p className="text-muted-foreground">
            El profesional ha sido notificado. Deposita el pago en escrow para comenzar.
          </p>
        </div>

        {/* Contract Details */}
        <div className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm space-y-4">
          <h4 className="font-semibold text-foreground">Detalles del contrato</h4>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Trabajo</span>
              <span className="text-foreground">Reparación de tubería</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Profesional</span>
              <span className="text-foreground">Carlos Mendez</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Monto acordado</span>
              <span className="text-xl font-bold text-foreground">${amount}</span>
            </div>
          </div>
        </div>

        {/* Escrow Explanation */}
        <div className="bg-primary/5 rounded-2xl p-5 border border-primary/20">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Shield className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-2">¿Cómo funciona el escrow?</h4>
              <ul className="space-y-2">
                {[
                  "Depositas el pago de forma segura",
                  "El profesional realiza el trabajo",
                  "Confirmas que está completo",
                  "El pago se libera al profesional",
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <span className="text-xs font-medium text-primary">{i + 1}</span>
                    </div>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Guarantee */}
        <div className="flex items-center gap-3 p-4 rounded-xl bg-muted/50">
          <Shield className="w-5 h-5 text-primary" />
          <div>
            <p className="text-sm font-medium text-foreground">Garantía Solva incluida</p>
            <p className="text-xs text-muted-foreground">Protección contra fraudes y disputas</p>
          </div>
        </div>
      </div>

      <div className="sticky bottom-0 bg-background/80 backdrop-blur-xl border-t border-border/50 px-6 py-4">
        <Button
          onClick={() => setStep("payment")}
          className="w-full h-14 rounded-xl text-base font-semibold shadow-lg shadow-primary/20"
        >
          Continuar al pago
          <ChevronRight className="w-5 h-5 ml-2" />
        </Button>
      </div>
    </div>
  )
}
