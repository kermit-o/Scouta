"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { 
  ArrowLeft, 
  Camera, 
  MapPin, 
  Calendar, 
  DollarSign, 
  Clock,
  X,
  ChevronRight,
  Sparkles
} from "lucide-react"

interface PostJobScreenProps {
  onBack: () => void
  onSubmit: () => void
}

const CATEGORIES = [
  { id: "cleaning", name: "Limpieza", icon: "🧹" },
  { id: "plumbing", name: "Plomería", icon: "🔧" },
  { id: "electrical", name: "Electricidad", icon: "⚡" },
  { id: "painting", name: "Pintura", icon: "🎨" },
  { id: "moving", name: "Mudanzas", icon: "📦" },
  { id: "gardening", name: "Jardinería", icon: "🌱" },
  { id: "carpentry", name: "Carpintería", icon: "🪚" },
  { id: "other", name: "Otro", icon: "✨" },
]

export function PostJobScreen({ onBack, onSubmit }: PostJobScreenProps) {
  const [step, setStep] = useState<1 | 2 | 3>(1)
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [category, setCategory] = useState<string | null>(null)
  const [budget, setBudget] = useState("")
  const [location, setLocation] = useState("")
  const [date, setDate] = useState("")
  const [time, setTime] = useState("")
  const [photos, setPhotos] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(false)

  const handleAddPhoto = () => {
    // Simulate adding a photo
    setPhotos([...photos, `/placeholder.svg?height=200&width=200&text=Foto${photos.length + 1}`])
  }

  const handleRemovePhoto = (index: number) => {
    setPhotos(photos.filter((_, i) => i !== index))
  }

  const handleSubmit = async () => {
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setIsLoading(false)
    onSubmit()
  }

  const canProceedStep1 = title && description && category
  const canProceedStep2 = budget && location
  const canSubmit = canProceedStep1 && canProceedStep2

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-xl border-b border-border/50">
        <div className="flex items-center gap-4 px-6 py-4">
          <button
            onClick={step > 1 ? () => setStep((step - 1) as 1 | 2) : onBack}
            className="w-10 h-10 rounded-full bg-card border border-border/50 flex items-center justify-center shadow-sm hover:bg-muted/50 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-semibold text-foreground">Publicar trabajo</h1>
            <p className="text-sm text-muted-foreground">Paso {step} de 3</p>
          </div>
        </div>
        {/* Progress */}
        <div className="px-6 pb-4">
          <div className="flex gap-2">
            <div className="h-1 flex-1 rounded-full bg-primary" />
            <div className={`h-1 flex-1 rounded-full transition-colors ${step >= 2 ? "bg-primary" : "bg-border"}`} />
            <div className={`h-1 flex-1 rounded-full transition-colors ${step >= 3 ? "bg-primary" : "bg-border"}`} />
          </div>
        </div>
      </div>

      <div className="flex-1 px-6 py-6">
        {step === 1 && (
          <div className="space-y-6">
            {/* Title */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Título del trabajo
              </label>
              <Input
                placeholder="Ej: Reparación de tubería en baño"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="h-14 bg-card border-border/50 rounded-xl text-base shadow-sm"
              />
            </div>

            {/* Category */}
            <div className="space-y-3">
              <label className="text-sm font-medium text-foreground">
                Categoría
              </label>
              <div className="grid grid-cols-4 gap-3">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setCategory(cat.id)}
                    className={`flex flex-col items-center gap-2 p-3 rounded-xl border-2 transition-all ${
                      category === cat.id
                        ? "border-primary bg-primary/5 shadow-sm"
                        : "border-border/50 bg-card hover:border-border"
                    }`}
                  >
                    <span className="text-2xl">{cat.icon}</span>
                    <span className="text-xs font-medium text-foreground">{cat.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Descripción
              </label>
              <Textarea
                placeholder="Describe el trabajo que necesitas con el mayor detalle posible..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="min-h-32 bg-card border-border/50 rounded-xl text-base shadow-sm resize-none"
              />
              <p className="text-xs text-muted-foreground">
                {description.length}/500 caracteres
              </p>
            </div>

            {/* Photos */}
            <div className="space-y-3">
              <label className="text-sm font-medium text-foreground">
                Fotos (opcional)
              </label>
              <div className="flex gap-3 overflow-x-auto pb-2">
                {photos.map((photo, index) => (
                  <div key={index} className="relative flex-shrink-0">
                    <img
                      src={photo}
                      alt={`Foto ${index + 1}`}
                      className="w-20 h-20 rounded-xl object-cover"
                    />
                    <button
                      onClick={() => handleRemovePhoto(index)}
                      className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
                {photos.length < 5 && (
                  <button
                    onClick={handleAddPhoto}
                    className="w-20 h-20 rounded-xl border-2 border-dashed border-border flex flex-col items-center justify-center gap-1 hover:border-primary hover:bg-primary/5 transition-colors flex-shrink-0"
                  >
                    <Camera className="w-5 h-5 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Añadir</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            {/* Budget */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Presupuesto estimado
              </label>
              <div className="relative">
                <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type="number"
                  placeholder="0.00"
                  value={budget}
                  onChange={(e) => setBudget(e.target.value)}
                  className="pl-12 h-14 bg-card border-border/50 rounded-xl text-base shadow-sm"
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Los profesionales podrán hacer ofertas diferentes
              </p>
            </div>

            {/* Location */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Ubicación
              </label>
              <div className="relative">
                <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  placeholder="Dirección o zona"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="pl-12 pr-12 h-14 bg-card border-border/50 rounded-xl text-base shadow-sm"
                />
                <button className="absolute right-4 top-1/2 -translate-y-1/2 text-primary">
                  <MapPin className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Date */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Fecha preferida (opcional)
              </label>
              <div className="relative">
                <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="pl-12 h-14 bg-card border-border/50 rounded-xl text-base shadow-sm"
                />
              </div>
            </div>

            {/* Time */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Hora preferida (opcional)
              </label>
              <div className="relative">
                <Clock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="pl-12 h-14 bg-card border-border/50 rounded-xl text-base shadow-sm"
                />
              </div>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-6">
            {/* Summary Card */}
            <div className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm">
              <h3 className="font-semibold text-foreground mb-4">Resumen del trabajo</h3>
              
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-lg">{CATEGORIES.find(c => c.id === category)?.icon}</span>
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{title}</p>
                    <p className="text-sm text-muted-foreground">{CATEGORIES.find(c => c.id === category)?.name}</p>
                  </div>
                </div>

                <div className="h-px bg-border" />

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Presupuesto</span>
                    <span className="font-semibold text-foreground">${budget}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Ubicación</span>
                    <span className="text-sm text-foreground">{location}</span>
                  </div>
                  {date && (
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Fecha</span>
                      <span className="text-sm text-foreground">{date}</span>
                    </div>
                  )}
                  {photos.length > 0 && (
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Fotos</span>
                      <span className="text-sm text-foreground">{photos.length} adjuntas</span>
                    </div>
                  )}
                </div>

                <div className="h-px bg-border" />

                <p className="text-sm text-muted-foreground line-clamp-3">
                  {description}
                </p>
              </div>
            </div>

            {/* Guarantee Info */}
            <div className="bg-primary/5 rounded-2xl p-4 border border-primary/20">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Sparkles className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="font-medium text-foreground mb-1">Garantía Solva incluida</p>
                  <p className="text-sm text-muted-foreground">
                    Tu pago está protegido. Solo se libera cuando confirmas que el trabajo está completo.
                  </p>
                </div>
              </div>
            </div>

            {/* Tips */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-foreground">Qué sigue:</h4>
              <div className="space-y-2">
                {[
                  "Los profesionales verán tu trabajo y enviarán ofertas",
                  "Revisa perfiles y elige al mejor candidato",
                  "Acuerda los detalles y deposita en escrow",
                ].map((tip, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                      <span className="text-xs font-medium text-muted-foreground">{i + 1}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">{tip}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="sticky bottom-0 bg-background/80 backdrop-blur-xl border-t border-border/50 px-6 py-4">
        {step === 1 && (
          <Button
            onClick={() => setStep(2)}
            disabled={!canProceedStep1}
            className="w-full h-14 rounded-xl text-base font-semibold shadow-lg shadow-primary/20"
          >
            Continuar
            <ChevronRight className="w-5 h-5 ml-2" />
          </Button>
        )}
        {step === 2 && (
          <Button
            onClick={() => setStep(3)}
            disabled={!canProceedStep2}
            className="w-full h-14 rounded-xl text-base font-semibold shadow-lg shadow-primary/20"
          >
            Revisar y publicar
            <ChevronRight className="w-5 h-5 ml-2" />
          </Button>
        )}
        {step === 3 && (
          <Button
            onClick={handleSubmit}
            disabled={!canSubmit || isLoading}
            className="w-full h-14 rounded-xl text-base font-semibold shadow-lg shadow-primary/20"
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
            ) : (
              <>
                Publicar trabajo
                <Sparkles className="w-5 h-5 ml-2" />
              </>
            )}
          </Button>
        )}
      </div>
    </div>
  )
}
